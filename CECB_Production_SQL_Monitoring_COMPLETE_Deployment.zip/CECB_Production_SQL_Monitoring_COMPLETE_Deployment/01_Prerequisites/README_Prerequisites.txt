# CECB SQL SERVER DATABASE MONITORING SYSTEM
## 01 – PREREQUISITES FOLDER README

### 1. PURPOSE

This folder contains the initial production environment assessment and verification scripts.

The purpose is to check whether the production SQL Server environment is ready for the proposed monitoring, backup and restore management system.

### 2. FILE STRUCTURE

```text
01_Prerequisites
│
├── README_Prerequisites.txt
└── 00_Production_Precheck.sql
```

### 3. FILE DESCRIPTION

#### 00_Production_Precheck.sql

**Purpose:**

Checks important SQL Server configuration and environment details before deployment.

**Expected checks:**
- SQL Server version and edition.
- SQL Server instance information.
- Database availability.
- Database recovery models.
- SQL Server service information.
- Existing SQL Server Audit configurations.
- Existing Extended Events sessions.
- Required database and server objects.

**Important:** This script is intended for environment assessment. Review its contents and permissions before execution.

### 4. HOW TO EXECUTE

1. Obtain DBA/PM approval to perform the production pre-check.
2. Open SQL Server Management Studio.
3. Connect to the approved production SQL Server instance.
4. Open `00_Production_Precheck.sql`.
5. Review the script before execution.
6. Execute the script.
7. Review all result sets and error messages.

### 5. VERIFICATION

Check the following:

- SQL Server connection is successful.
- All required databases are identified.
- Recovery models are recorded correctly.
- Existing Audit configurations are documented.
- Existing Extended Events sessions are identified.
- Any missing prerequisites are reported.

Save the results for the production deployment assessment.

### 6. TROUBLESHOOTING

**Connection failure:**
Check the SQL Server instance name, network connectivity and login permissions.

**Permission denied:**
Ask the DBA to provide the required read-only diagnostic permissions.

**Database not found:**
Confirm the database name and whether it is available on the production instance.

### 7. IMPORTANT NOTES

- Do not modify production configurations during the pre-check.
- Do not create or delete databases.
- Do not enable or disable existing audits.
- Do not modify database recovery models.
- Do not change SQL Server permissions without approval.
- Record the existing configuration before deployment.

### 8. EXPECTED RESULT

A documented assessment of the production SQL Server environment, identifying whether the proposed monitoring and backup system prerequisites are satisfied.

**Project:** SQL Server Database Activity Monitoring, Backup and Restore Management System

**Organization:** Central Engineering Consultancy Bureau (CECB)

**Document:** Prerequisites – Technical README

**Deployment Status:** Proposed – Pending Production Approval