/*
============================================================
CECB PRODUCTION PRE-CHECK
READ-ONLY DIAGNOSTIC SCRIPT
============================================================

This script does not create or modify databases.
Run only with an approved DBA account.
============================================================
*/

USE master;
GO

SET NOCOUNT ON;

PRINT '1. SQL SERVER INFORMATION';

SELECT
    @@SERVERNAME AS ServerName,
    SERVERPROPERTY('ServerName') AS InstanceName,
    SERVERPROPERTY('MachineName') AS MachineName,
    SERVERPROPERTY('Edition') AS Edition,
    SERVERPROPERTY('ProductVersion') AS ProductVersion,
    SERVERPROPERTY('ProductLevel') AS ProductLevel,
    SERVERPROPERTY('EngineEdition') AS EngineEdition;

PRINT '2. REQUIRED DATABASES';

SELECT
    name AS DatabaseName,
    state_desc AS DatabaseState,
    recovery_model_desc AS RecoveryModel,
    compatibility_level AS CompatibilityLevel
FROM sys.databases
WHERE name IN
(
    N'CECB_ERP',
    N'CECB_Monitoring',
    N'CECB_System',
    N'LeaveDB',
    N'SP_USER_LOGIN'
)
ORDER BY name;

PRINT '3. SQL SERVER SERVICES';

SELECT
    servicename,
    status_desc,
    startup_type_desc,
    service_account
FROM sys.dm_server_services
WHERE servicename LIKE N'SQL Server%';

PRINT '4. EXISTING SERVER AUDITS';

SELECT
    name AS AuditName,
    is_state_enabled,
    type_desc,
    on_failure_desc
FROM sys.server_audits;

PRINT '5. EXISTING SERVER AUDIT SPECIFICATIONS';

SELECT
    name AS SpecificationName,
    is_state_enabled
FROM sys.server_audit_specifications;

PRINT '6. EXISTING EXTENDED EVENT SESSIONS';

SELECT
    name AS SessionName,
    startup_state
FROM sys.server_event_sessions
WHERE name LIKE N'CECB%';

PRINT '7. SQL SERVER AGENT STATUS';

SELECT
    servicename,
    status_desc,
    startup_type_desc
FROM sys.dm_server_services
WHERE servicename LIKE N'SQL Server Agent%';

PRINT '8. DATABASE FILE LOCATIONS';

SELECT
    DB_NAME(database_id) AS DatabaseName,
    physical_name,
    type_desc,
    size * 8 / 1024 AS SizeMB
FROM sys.master_files
WHERE DB_NAME(database_id) IN
(
    N'CECB_ERP',
    N'CECB_Monitoring',
    N'CECB_System',
    N'LeaveDB',
    N'SP_USER_LOGIN'
)
ORDER BY DatabaseName, type_desc;

PRINT '9. SERVER AUDIT FILE LOCATIONS';

SELECT
    name AS AuditName,
    log_file_path,
    log_file_name,
    max_file_size,
    max_rollover_files
FROM sys.server_file_audits;

PRINT '10. PRE-CHECK COMPLETED';

PRINT 'Review all results with the DBA before deployment.';
GO