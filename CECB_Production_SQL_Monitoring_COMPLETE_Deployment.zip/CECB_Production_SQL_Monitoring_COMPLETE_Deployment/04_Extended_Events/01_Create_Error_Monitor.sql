/*
============================================================
CECB EXTENDED EVENTS ERROR MONITOR
============================================================

Session:
CECB_Error_Monitor

Target:
C:\CECB_Audit\CECB_Error_Monitor.xel

Captures:
- SQL Server errors with severity >= 11
- Client application
- Client hostname
- Database
- SQL statement
- Username

IMPORTANT:
- Audit directory must exist.
- SQL Server service account needs Modify permission.
- Review file retention and disk capacity with DBA.
============================================================
*/

USE master;
GO

SET NOCOUNT ON;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.server_event_sessions
    WHERE name = N'CECB_Error_Monitor'
)
BEGIN

    CREATE EVENT SESSION [CECB_Error_Monitor]
    ON SERVER

    ADD EVENT sqlserver.error_reported
    (
        ACTION
        (
            sqlserver.client_app_name,
            sqlserver.client_hostname,
            sqlserver.database_name,
            sqlserver.sql_text,
            sqlserver.username
        )

        WHERE
        (
            [severity] >= (11)
        )
    )

    ADD TARGET package0.event_file
    (
        SET
            filename = N'C:\CECB_Audit\CECB_Error_Monitor.xel',
            max_file_size = (50),
            max_rollover_files = (20)
    )

    WITH
    (
        MAX_MEMORY = 4096 KB,
        EVENT_RETENTION_MODE = ALLOW_SINGLE_EVENT_LOSS,
        MAX_DISPATCH_LATENCY = 5 SECONDS,
        MAX_EVENT_SIZE = 0 KB,
        MEMORY_PARTITION_MODE = NONE,
        TRACK_CAUSALITY = ON,
        STARTUP_STATE = ON
    );

    PRINT 'CECB_Error_Monitor session created.';

END
ELSE
BEGIN

    PRINT 'CECB_Error_Monitor already exists.';
    PRINT 'Existing configuration was not modified.';

END;
GO

/* START SESSION IF IT IS NOT ALREADY RUNNING */

IF EXISTS
(
    SELECT 1
    FROM sys.server_event_sessions
    WHERE name = N'CECB_Error_Monitor'
)
AND NOT EXISTS
(
    SELECT 1
    FROM sys.dm_xe_sessions
    WHERE name = N'CECB_Error_Monitor'
)
BEGIN

    ALTER EVENT SESSION [CECB_Error_Monitor]
    ON SERVER
    STATE = START;

    PRINT 'CECB_Error_Monitor started.';

END;
GO

/* VERIFY SESSION */

SELECT
    s.name AS SessionName,
    s.startup_state AS StartupEnabled,
    CASE
        WHEN x.name IS NULL THEN 'STOPPED'
        ELSE 'RUNNING'
    END AS CurrentStatus
FROM sys.server_event_sessions AS s
LEFT JOIN sys.dm_xe_sessions AS x
    ON s.name = x.name
WHERE s.name = N'CECB_Error_Monitor';
GO