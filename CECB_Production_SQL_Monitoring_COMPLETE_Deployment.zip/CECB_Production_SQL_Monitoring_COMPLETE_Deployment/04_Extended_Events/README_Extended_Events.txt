# CECB SQL SERVER DATABASE MONITORING SYSTEM
## 04 – EXTENDED EVENTS FOLDER README

### 1. PURPOSE

This folder contains SQL Server Extended Events configuration scripts used to capture SQL Server error events.

Extended Events provides information about errors reported by the SQL Server Database Engine.

### 2. FILE STRUCTURE

```text
04_Extended_Events
│
├── README_Extended_Events.txt
└── 01_Create_Error_Monitor.sql
```

### 3. FILE DESCRIPTION

#### 01_Create_Error_Monitor.sql

**Purpose:**

Creates and starts the SQL Server Extended Events session named:

`CECB_Error_Monitor`

**Main functions:**

- Monitors SQL Server error events.
- Captures errors with severity 11 or higher.
- Records error timestamps.
- Captures username information when available.
- Captures client hostname.
- Captures database name.
- Captures application name.
- Captures SQL statement information when available.
- Stores collected events in Extended Events files.

**Event monitored:**

`sqlserver.error_reported`

**File target:**

`C:\CECB_Audit\CECB_Error_Monitor.xel`

**File configuration:**
- Maximum file size: 50 MB.
- Maximum rollover files: 20.
- Event retention mode: ALLOW_SINGLE_EVENT_LOSS.
- Startup state: ON.

### 4. EXECUTION REQUIREMENTS

Before executing the script:

1. Confirm the production SQL Server instance.
2. Confirm that the audit directory exists.
3. Confirm SQL Server service account permissions.
4. Verify Extended Events action availability for the SQL Server version.
5. Check whether `CECB_Error_Monitor` already exists.
6. Obtain DBA approval.

### 5. EXECUTION PROCEDURE

1. Open SQL Server Management Studio.
2. Connect to the approved SQL Server instance.
3. Open `01_Create_Error_Monitor.sql`.
4. Review the configuration and file target.
5. Execute the script after approval.
6. Check the Messages tab for errors.
7. Verify that the Extended Events session is running.

### 6. VERIFICATION

Check the session configuration:

```sql
SELECT
    name,
    startup_state
FROM sys.server_event_sessions
WHERE name = 'CECB_Error_Monitor';
GO
```

Check the current session status:

```sql
SELECT
    name,
    create_time
FROM sys.dm_xe_sessions
WHERE name = 'CECB_Error_Monitor';
GO
```

Check the configured event file target:

```sql
SELECT
    S.name AS SessionName,
    T.target_name,
    CAST(T.target_data AS XML) AS TargetData
FROM sys.dm_xe_sessions S
INNER JOIN sys.dm_xe_session_targets T
    ON S.address = T.event_session_address
WHERE S.name = 'CECB_Error_Monitor';
GO
```

### 7. TROUBLESHOOTING

**Session not found:**
Check whether the creation script was executed successfully.

**Session is not running:**
Check the session state and SQL Server permissions.

**XEL file not created:**
Check the SQL Server service account folder permissions and target configuration.

**No error records:**
Confirm that SQL Server errors meeting the configured severity condition have occurred.

**Action not available:**
Verify the Extended Events action name against the SQL Server version and metadata.

### 8. SECURITY AND DEPLOYMENT NOTES

- Do not remove existing Extended Events sessions.
- Do not overwrite existing event files.
- Protect XEL files from unauthorized access.
- Monitor disk usage and rollover settings.
- Review event retention requirements with the DBA.
- Do not assume that all failed SQL statements generate severity 11 or higher errors.
- Review the impact of error monitoring before production activation.

### 9. RELATIONSHIP WITH OTHER COMPONENTS

The Extended Events session produces `.xel` files.

The collector procedure:

`05_Collectors\02_usp_CollectUserErrors.sql`

reads those files and inserts the error records into:

`CECB_Monitoring.dbo.UserErrorLog`

The collected records are then available for reporting.

### 10. EXPECTED RESULT

A configured Extended Events session that captures approved SQL Server error events and stores them in the designated event file directory.

**Project:** SQL Server Database Activity Monitoring, Backup and Restore Management System

**Organization:** Central Engineering Consultancy Bureau (CECB)

**Document:** Extended Events – Technical README

**Deployment Status:** Proposed – Pending Production Approval