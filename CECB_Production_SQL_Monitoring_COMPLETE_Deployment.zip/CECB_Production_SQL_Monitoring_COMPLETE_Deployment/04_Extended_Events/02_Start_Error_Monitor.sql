/*
============================================================
START CECB EXTENDED EVENTS ERROR MONITOR
============================================================
STATE-CHANGING SCRIPT. Execute only after written DBA approval.
This starts the session for the current SQL Server service run.
The session startup_state remains OFF; automatic startup after
SQL Server restart is not enabled by this script.
============================================================
*/
USE master;
GO
SET NOCOUNT ON;
IF NOT EXISTS (SELECT 1 FROM sys.server_event_sessions WHERE name=N'CECB_Error_Monitor')
    THROW 50040, 'CECB_Error_Monitor does not exist. Run the create script first.', 1;
IF NOT EXISTS (SELECT 1 FROM sys.dm_xe_sessions WHERE name=N'CECB_Error_Monitor')
    ALTER EVENT SESSION [CECB_Error_Monitor] ON SERVER STATE=START;
GO
SELECT S.name,
       CASE WHEN X.name IS NULL THEN 'STOPPED' ELSE 'RUNNING' END AS RuntimeStatus
FROM sys.server_event_sessions AS S
LEFT JOIN sys.dm_xe_sessions AS X ON X.name=S.name
WHERE S.name=N'CECB_Error_Monitor';
GO
