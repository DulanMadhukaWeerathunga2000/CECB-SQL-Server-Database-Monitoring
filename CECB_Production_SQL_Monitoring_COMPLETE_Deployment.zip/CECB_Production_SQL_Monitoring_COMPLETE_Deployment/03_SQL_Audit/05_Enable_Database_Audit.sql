/*
============================================================
ENABLE CECB_SYSTEM DATABASE AUDIT SPECIFICATION
============================================================
STATE-CHANGING SCRIPT. Execute only after written DBA approval.
============================================================
*/
USE [CECB_System];
GO
SET NOCOUNT ON;
IF NOT EXISTS (SELECT 1 FROM sys.database_audit_specifications WHERE name=N'CECB_System_Database_Audit')
    THROW 50030, 'CECB_System_Database_Audit does not exist.', 1;
ALTER DATABASE AUDIT SPECIFICATION [CECB_System_Database_Audit] WITH (STATE=ON);
GO
SELECT name, is_state_enabled
FROM sys.database_audit_specifications
WHERE name=N'CECB_System_Database_Audit';
GO
