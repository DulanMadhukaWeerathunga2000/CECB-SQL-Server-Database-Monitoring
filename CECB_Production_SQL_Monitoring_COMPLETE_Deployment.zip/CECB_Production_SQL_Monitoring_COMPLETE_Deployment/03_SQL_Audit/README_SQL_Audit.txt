# CECB SQL SERVER DATABASE MONITORING SYSTEM
## 03 – SQL AUDIT FOLDER README

### 1. PURPOSE

This folder contains SQL Server Audit configuration scripts used to monitor database and server-level activities.

SQL Server Audit captures login events, logout events and selected database activities for security monitoring and accountability.

### 2. FILE STRUCTURE

```text
03_SQL_Audit
│
├── README_SQL_Audit.txt
├── 01_Create_Server_Audits.sql
├── 02_Server_Audit_Specifications.sql
├── 03_CECB_System_Database_Audit.sql
└── 04_Enable_Server_Audits.sql
```

### 3. FILE DESCRIPTIONS

#### 01_Create_Server_Audits.sql

**Purpose:** Creates the required SQL Server Audit objects.

Configured audits:

- CECB_Server_Audit
- Full_Server_Audit
- Role_Activity_Audit

Audit files are configured to be stored in:

`C:\CECB_Audit\`

The script defines file size, rollover and failure-handling settings.

It does not enable the audits.

#### 02_Server_Audit_Specifications.sql

**Purpose:** Creates server-level Audit Specifications.

Configured specifications:

- CECB_Login_Audit
- Server_Wide_Tracking
- Role_Activity_Spec

These specifications capture:

- Successful login events.
- Failed login events.
- Logout events.

It does not enable the specifications.

#### 03_CECB_System_Database_Audit.sql

**Purpose:** Creates the database-level Audit Specification for `CECB_System`.

Configured activities include:

- SELECT
- INSERT
- UPDATE
- DELETE
- EXECUTE
- Schema object changes

**Important:** Confirm that `CECB_System` is the correct production database before execution.

#### 04_Enable_Server_Audits.sql

**Purpose:** Enables the previously created SQL Server Audits and Server Audit Specifications.

**Important:** This script changes the active SQL Server Audit configuration. Execute only after DBA approval and successful configuration checks.

### 4. EXECUTION ORDER

For a new approved production deployment:

1. Confirm the production SQL Server instance.
2. Confirm the `C:\CECB_Audit\` directory.
3. Confirm SQL Server service account permissions.
4. Execute `01_Create_Server_Audits.sql`.
5. Execute `02_Server_Audit_Specifications.sql`.
6. Execute `03_CECB_System_Database_Audit.sql`.
7. Review all Audit configurations.
8. Obtain final DBA approval.
9. Execute `04_Enable_Server_Audits.sql`.

### 5. REQUIRED PERMISSIONS

The deployment account requires appropriate SQL Server permissions to:

- Create Server Audits.
- Create Server Audit Specifications.
- Create Database Audit Specifications.
- Enable and manage Audit objects.

The SQL Server Database Engine service account requires the necessary folder permissions to write Audit files.

### 6. VERIFICATION

Check configured Server Audits:

```sql
USE master;
GO

SELECT
    name,
    is_state_enabled,
    type_desc,
    on_failure_desc
FROM sys.server_audits;
GO
```

Check Server Audit Specifications:

```sql
SELECT
    name,
    is_state_enabled,
    audit_guid
FROM sys.server_audit_specifications;
GO
```

Check Database Audit Specifications:

```sql
USE CECB_System;
GO

SELECT
    name,
    is_state_enabled
FROM sys.database_audit_specifications;
GO
```

Check Audit files:

```sql
SELECT *
FROM sys.fn_get_audit_file
(
    'C:\CECB_Audit\*.sqlaudit',
    DEFAULT,
    DEFAULT
);
GO
```

### 7. TROUBLESHOOTING

**Audit file cannot be created:**
Check folder existence and SQL Server service account permissions.

**Audit already exists:**
Review the existing configuration. Do not recreate or overwrite existing production Audit objects.

**Permission denied:**
Contact the DBA to review server-level and database-level permissions.

**Audit is disabled:**
Check the Audit state and obtain approval before enabling it.

**No activity records:**
Check the Audit Specification, enabled state, event configuration and file target.

### 8. SECURITY AND DEPLOYMENT NOTES

- Do not disable existing production Audits.
- Do not delete existing `.sqlaudit` files.
- Preserve existing Audit configurations.
- Review Audit file retention requirements.
- Protect Audit files from unauthorized access.
- Monitor available disk space.
- Confirm that the Audit failure setting is acceptable to the DBA.
- Test collection before enabling automated reporting.

### 9. EXPECTED RESULT

The SQL Server Audit system should capture approved server and database activities and store them in the configured Audit directory.

These records will be collected by the monitoring procedures in the `05_Collectors` folder.

**Project:** SQL Server Database Activity Monitoring, Backup and Restore Management System

**Organization:** Central Engineering Consultancy Bureau (CECB)

**Document:** SQL Audit – Technical README

**Deployment Status:** Proposed – Pending Production Approval