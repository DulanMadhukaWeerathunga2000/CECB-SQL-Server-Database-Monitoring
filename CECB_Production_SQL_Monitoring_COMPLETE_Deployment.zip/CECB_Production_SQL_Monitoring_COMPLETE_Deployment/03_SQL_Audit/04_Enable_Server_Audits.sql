USE master;
GO

-- Enable only after DBA approval.

ALTER SERVER AUDIT [CECB_Server_Audit]
WITH (STATE = ON);
GO

ALTER SERVER AUDIT [Full_Server_Audit]
WITH (STATE = ON);
GO

ALTER SERVER AUDIT [Role_Activity_Audit]
WITH (STATE = ON);
GO

ALTER SERVER AUDIT SPECIFICATION [CECB_Login_Audit]
WITH (STATE = ON);
GO

ALTER SERVER AUDIT SPECIFICATION [Server_Wide_Tracking]
WITH (STATE = ON);
GO

ALTER SERVER AUDIT SPECIFICATION [Role_Activity_Spec]
WITH (STATE = ON);
GO