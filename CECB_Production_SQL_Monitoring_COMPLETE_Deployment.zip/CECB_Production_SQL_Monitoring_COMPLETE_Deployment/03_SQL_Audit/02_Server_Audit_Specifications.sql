/*
============================================================
CECB SERVER AUDIT SPECIFICATIONS
============================================================

Creates missing server audit specifications only.

Existing specifications are not overwritten.
============================================================
*/

USE master;
GO

SET NOCOUNT ON;


/* --------------------------------------------------------
   1. CECB LOGIN AUDIT
-------------------------------------------------------- */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.server_audit_specifications
    WHERE name = N'CECB_Login_Audit'
)
BEGIN

    IF EXISTS
    (
        SELECT 1
        FROM sys.server_audits
        WHERE name = N'CECB_Server_Audit'
    )
    BEGIN

        CREATE SERVER AUDIT SPECIFICATION
            [CECB_Login_Audit]

        FOR SERVER AUDIT [CECB_Server_Audit]

            ADD (FAILED_LOGIN_GROUP),
            ADD (SUCCESSFUL_LOGIN_GROUP),
            ADD (LOGOUT_GROUP);

        PRINT 'CECB_Login_Audit created.';

    END
    ELSE
    BEGIN
        THROW 50001, 'CECB_Server_Audit does not exist.', 1;
    END;

END
ELSE
BEGIN
    PRINT 'CECB_Login_Audit already exists.';
END;
GO


/* --------------------------------------------------------
   2. SERVER WIDE TRACKING
-------------------------------------------------------- */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.server_audit_specifications
    WHERE name = N'Server_Wide_Tracking'
)
BEGIN

    IF EXISTS
    (
        SELECT 1
        FROM sys.server_audits
        WHERE name = N'Full_Server_Audit'
    )
    BEGIN

        CREATE SERVER AUDIT SPECIFICATION
            [Server_Wide_Tracking]

        FOR SERVER AUDIT [Full_Server_Audit]

            ADD (FAILED_LOGIN_GROUP),
            ADD (SUCCESSFUL_LOGIN_GROUP),
            ADD (LOGOUT_GROUP);

        PRINT 'Server_Wide_Tracking created.';

    END
    ELSE
    BEGIN
        THROW 50002, 'Full_Server_Audit does not exist.', 1;
    END;

END
ELSE
BEGIN
    PRINT 'Server_Wide_Tracking already exists.';
END;
GO


/* --------------------------------------------------------
   3. ROLE ACTIVITY SPECIFICATION
-------------------------------------------------------- */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.server_audit_specifications
    WHERE name = N'Role_Activity_Spec'
)
BEGIN

    IF EXISTS
    (
        SELECT 1
        FROM sys.server_audits
        WHERE name = N'Role_Activity_Audit'
    )
    BEGIN

        CREATE SERVER AUDIT SPECIFICATION
            [Role_Activity_Spec]

        FOR SERVER AUDIT [Role_Activity_Audit]

            ADD (FAILED_LOGIN_GROUP),
            ADD (SUCCESSFUL_LOGIN_GROUP),
            ADD (LOGOUT_GROUP);

        PRINT 'Role_Activity_Spec created.';

    END
    ELSE
    BEGIN
        THROW 50003, 'Role_Activity_Audit does not exist.', 1;
    END;

END
ELSE
BEGIN
    PRINT 'Role_Activity_Spec already exists.';
END;
GO


/* --------------------------------------------------------
   4. REVIEW SPECIFICATIONS
-------------------------------------------------------- */

SELECT
    name AS SpecificationName,
    is_state_enabled
FROM sys.server_audit_specifications
WHERE name IN
(
    N'CECB_Login_Audit',
    N'Server_Wide_Tracking',
    N'Role_Activity_Spec'
);
GO


/* --------------------------------------------------------
   5. REVIEW AUDIT ACTIONS
-------------------------------------------------------- */

SELECT
    sas.name AS SpecificationName,
    sd.audit_action_name,
    sd.audited_result
FROM sys.server_audit_specifications AS sas
INNER JOIN sys.server_audit_specification_details AS sd
    ON sas.server_specification_id =
       sd.server_specification_id
WHERE sas.name IN
(
    N'CECB_Login_Audit',
    N'Server_Wide_Tracking',
    N'Role_Activity_Spec'
)
ORDER BY sas.name, sd.audit_action_name;
GO