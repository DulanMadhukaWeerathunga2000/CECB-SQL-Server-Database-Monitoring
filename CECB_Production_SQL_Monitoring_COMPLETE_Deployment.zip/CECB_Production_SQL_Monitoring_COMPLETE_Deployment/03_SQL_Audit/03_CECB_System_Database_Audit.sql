/*
============================================================
CECB_SYSTEM DATABASE AUDIT
============================================================

Target database: CECB_System
Target server audit: CECB_Server_Audit

IMPORTANT:
- Confirm CECB_System exists.
- Confirm CECB_Server_Audit is enabled.
- Review auditing scope with DBA.
- This script does not change database users or roles.
============================================================
*/

USE master;
GO

SET NOCOUNT ON;

IF DB_ID(N'CECB_System') IS NULL
BEGIN
    THROW 50010, 'CECB_System database does not exist.', 1;
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.server_audits
    WHERE name = N'CECB_Server_Audit'
)
BEGIN
    THROW 50011, 'CECB_Server_Audit does not exist.', 1;
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.server_audits
    WHERE name = N'CECB_Server_Audit'
      AND is_state_enabled = 1
)
BEGIN
    THROW 50012, 'CECB_Server_Audit is not enabled. DBA must review and enable it first.', 1;
END;
GO

USE [CECB_System];
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.database_audit_specifications
    WHERE name = N'CECB_System_Database_Audit'
)
BEGIN

    CREATE DATABASE AUDIT SPECIFICATION
        [CECB_System_Database_Audit]

    FOR SERVER AUDIT [CECB_Server_Audit]

        ADD (SELECT ON DATABASE::[CECB_System] BY [public]),
        ADD (INSERT ON DATABASE::[CECB_System] BY [public]),
        ADD (UPDATE ON DATABASE::[CECB_System] BY [public]),
        ADD (DELETE ON DATABASE::[CECB_System] BY [public]),
        ADD (EXECUTE ON DATABASE::[CECB_System] BY [public]),
        ADD (SCHEMA_OBJECT_CHANGE_GROUP);

    PRINT 'CECB_System_Database_Audit created.';

    ALTER DATABASE AUDIT SPECIFICATION
        [CECB_System_Database_Audit]
    WITH (STATE = ON);

END
ELSE
BEGIN
    PRINT 'CECB_System_Database_Audit already exists.';
    PRINT 'Existing configuration was not modified.';
END;
GO

/* REVIEW DATABASE AUDIT */

SELECT
    name AS SpecificationName,
    is_state_enabled
FROM sys.database_audit_specifications
WHERE name = N'CECB_System_Database_Audit';
GO

SELECT
    d.name AS SpecificationName,
    s.audit_action_name,
    s.audited_result
FROM sys.database_audit_specifications AS d
INNER JOIN sys.database_audit_specification_details AS s
    ON d.database_specification_id =
       s.database_specification_id
WHERE d.name = N'CECB_System_Database_Audit'
ORDER BY s.audit_action_name;
GO