/*
============================================================
CECB SERVER AUDIT CREATION
============================================================

Audit folder:
C:\CECB_Audit\

REQUIREMENTS:
- SQL Server Audit support
- Appropriate server-level permissions
- Audit folder must already exist
- SQL Server service account needs write permission

This script creates missing audits only.
It does not alter existing audits.
============================================================
*/

USE master;
GO

SET NOCOUNT ON;

/* --------------------------------------------------------
   1. CECB SERVER AUDIT
-------------------------------------------------------- */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.server_audits
    WHERE name = N'CECB_Server_Audit'
)
BEGIN

    CREATE SERVER AUDIT [CECB_Server_Audit]
    TO FILE
    (
        FILEPATH = N'C:\CECB_Audit\',
        MAXSIZE = 100 MB,
        MAX_ROLLOVER_FILES = 100,
        RESERVE_DISK_SPACE = OFF
    )
    WITH
    (
        QUEUE_DELAY = 1000,
        ON_FAILURE = CONTINUE
    );

    PRINT 'CECB_Server_Audit created.';

END
ELSE
BEGIN
    PRINT 'CECB_Server_Audit already exists. Review existing configuration.';
END;
GO


/* --------------------------------------------------------
   2. FULL SERVER AUDIT
-------------------------------------------------------- */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.server_audits
    WHERE name = N'Full_Server_Audit'
)
BEGIN

    CREATE SERVER AUDIT [Full_Server_Audit]
    TO FILE
    (
        FILEPATH = N'C:\CECB_Audit\',
        MAXSIZE = 100 MB,
        MAX_ROLLOVER_FILES = 100,
        RESERVE_DISK_SPACE = OFF
    )
    WITH
    (
        QUEUE_DELAY = 1000,
        ON_FAILURE = CONTINUE
    );

    PRINT 'Full_Server_Audit created.';

END
ELSE
BEGIN
    PRINT 'Full_Server_Audit already exists. Review existing configuration.';
END;
GO


/* --------------------------------------------------------
   3. ROLE ACTIVITY AUDIT
-------------------------------------------------------- */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.server_audits
    WHERE name = N'Role_Activity_Audit'
)
BEGIN

    CREATE SERVER AUDIT [Role_Activity_Audit]
    TO FILE
    (
        FILEPATH = N'C:\CECB_Audit\',
        MAXSIZE = 100 MB,
        MAX_ROLLOVER_FILES = 100,
        RESERVE_DISK_SPACE = OFF
    )
    WITH
    (
        QUEUE_DELAY = 1000,
        ON_FAILURE = CONTINUE
    );

    PRINT 'Role_Activity_Audit created.';

END
ELSE
BEGIN
    PRINT 'Role_Activity_Audit already exists. Review existing configuration.';
END;
GO


/* --------------------------------------------------------
   4. REVIEW CREATED AUDITS
-------------------------------------------------------- */

SELECT
    name,
    is_state_enabled,
    type_desc,
    on_failure_desc
FROM sys.server_audits
WHERE name IN
(
    N'CECB_Server_Audit',
    N'Full_Server_Audit',
    N'Role_Activity_Audit'
);
GO