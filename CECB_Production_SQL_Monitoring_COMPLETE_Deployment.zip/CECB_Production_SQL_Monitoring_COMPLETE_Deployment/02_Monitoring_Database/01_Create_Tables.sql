/* ============================================================
   CECB DATABASE MONITORING SYSTEM
   USER ACTIVITY LOG TABLE
   SQL SERVER 2022
   ============================================================ */

USE CECB_Monitoring;
GO

SET NOCOUNT ON;
GO

/* ============================================================
   1. USER ACTIVITY LOG
   ============================================================ */

IF OBJECT_ID('dbo.UserActivityLog', 'U') IS NULL
BEGIN

    CREATE TABLE dbo.UserActivityLog
    (
        AuditID BIGINT IDENTITY(1,1) NOT NULL,

        EventTime DATETIME2(3) NOT NULL,

        UserName NVARCHAR(256) NULL,

        UserRole NVARCHAR(100) NULL,

        PCName NVARCHAR(256) NULL,

        IPAddress NVARCHAR(64) NULL,

        DatabaseName NVARCHAR(256) NULL,

        SchemaName NVARCHAR(256) NULL,

        TableName NVARCHAR(256) NULL,

        Activity NVARCHAR(100) NOT NULL,

        SQLStatement NVARCHAR(MAX) NULL,

        Status NVARCHAR(50) NULL,

        ErrorMessage NVARCHAR(MAX) NULL,

        AuditFileName NVARCHAR(512) NULL,

        AuditFileOffset BIGINT NULL,

        AuditSequenceNumber BIGINT NULL,

        SequenceGroupID UNIQUEIDENTIFIER NULL,

        ApplicationName NVARCHAR(256) NULL,

        CreatedDate DATETIME2(3)
            NOT NULL
            CONSTRAINT DF_UserActivityLog_CreatedDate
            DEFAULT SYSUTCDATETIME(),

        CONSTRAINT PK_UserActivityLog
            PRIMARY KEY CLUSTERED (AuditID)
    );

    PRINT 'UserActivityLog table created successfully.';

END
ELSE
BEGIN

    PRINT 'UserActivityLog already exists. No changes made.';

END;
GO

/* ============================================================
   2. ACTIVITY LOG INDEXES
   ============================================================ */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = 'IX_UserActivityLog_EventTime'
      AND object_id = OBJECT_ID('dbo.UserActivityLog')
)
BEGIN

    CREATE INDEX IX_UserActivityLog_EventTime
    ON dbo.UserActivityLog(EventTime DESC);

END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = 'IX_UserActivityLog_UserName'
      AND object_id = OBJECT_ID('dbo.UserActivityLog')
)
BEGIN

    CREATE INDEX IX_UserActivityLog_UserName
    ON dbo.UserActivityLog(UserName);

END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = 'IX_UserActivityLog_DatabaseName'
      AND object_id = OBJECT_ID('dbo.UserActivityLog')
)
BEGIN

    CREATE INDEX IX_UserActivityLog_DatabaseName
    ON dbo.UserActivityLog(DatabaseName);

END;
GO

/* ============================================================
   3. AUDIT FILE DUPLICATE PREVENTION
   ============================================================ */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = 'UX_UserActivityLog_AuditSource'
      AND object_id = OBJECT_ID('dbo.UserActivityLog')
)
BEGIN

    CREATE UNIQUE INDEX UX_UserActivityLog_AuditSource
    ON dbo.UserActivityLog
    (
        AuditFileName,
        AuditFileOffset
    )
    WHERE AuditFileName IS NOT NULL
      AND AuditFileOffset IS NOT NULL;

END;
GO

/* ============================================================
   4. VERIFY TABLE
   ============================================================ */

SELECT
    COLUMN_NAME,
    DATA_TYPE,
    CHARACTER_MAXIMUM_LENGTH,
    IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'dbo'
  AND TABLE_NAME = 'UserActivityLog'
ORDER BY ORDINAL_POSITION;
GO

PRINT 'USER ACTIVITY LOG SCHEMA COMPLETED.';
GO