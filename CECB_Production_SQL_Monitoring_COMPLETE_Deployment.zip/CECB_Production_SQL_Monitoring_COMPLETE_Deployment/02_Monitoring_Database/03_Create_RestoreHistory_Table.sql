/* ============================================================
   CECB DATABASE MONITORING SYSTEM
   DATABASE RESTORE HISTORY
   SQL SERVER 2022
   ============================================================ */

USE CECB_Monitoring;
GO

SET NOCOUNT ON;
GO

/* ============================================================
   1. RESTORE HISTORY TABLE
   ============================================================ */

IF OBJECT_ID('dbo.DatabaseRestoreHistory', 'U') IS NULL
BEGIN

    CREATE TABLE dbo.DatabaseRestoreHistory
    (
        RestoreID BIGINT IDENTITY(1,1) NOT NULL,

        RestoreHistoryID INT NULL,

        RestoreDate DATETIME2(3) NOT NULL,

        DatabaseName NVARCHAR(256) NOT NULL,

        BackupFile NVARCHAR(1000) NULL,

        RestoredBy NVARCHAR(256) NULL,

        PCName NVARCHAR(256) NULL,

        RestoreStatus NVARCHAR(50) NULL,

        Remarks NVARCHAR(MAX) NULL,

        CreatedDate DATETIME2(3)
            NOT NULL
            CONSTRAINT DF_DatabaseRestoreHistory_CreatedDate
            DEFAULT SYSUTCDATETIME(),

        CONSTRAINT PK_DatabaseRestoreHistory
            PRIMARY KEY CLUSTERED (RestoreID)
    );

    PRINT 'DatabaseRestoreHistory table created successfully.';

END
ELSE
BEGIN

    PRINT 'DatabaseRestoreHistory already exists. No changes made.';

END;
GO

/* ============================================================
   2. RESTORE HISTORY INDEX
   ============================================================ */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = 'IX_DatabaseRestoreHistory_RestoreDate'
      AND object_id = OBJECT_ID('dbo.DatabaseRestoreHistory')
)
BEGIN

    CREATE INDEX IX_DatabaseRestoreHistory_RestoreDate
    ON dbo.DatabaseRestoreHistory(RestoreDate DESC);

END;
GO

/* ============================================================
   3. RESTORE HISTORY UNIQUE INDEX
   ============================================================ */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = 'UX_DatabaseRestoreHistory_RestoreHistoryID'
      AND object_id = OBJECT_ID('dbo.DatabaseRestoreHistory')
)
BEGIN

    CREATE UNIQUE INDEX UX_DatabaseRestoreHistory_RestoreHistoryID
    ON dbo.DatabaseRestoreHistory(RestoreHistoryID)
    WHERE RestoreHistoryID IS NOT NULL;

END;
GO

/* ============================================================
   4. VERIFY TABLE
   ============================================================ */

SELECT
    COLUMN_NAME,
    DATA_TYPE,
    CHARACTER_MAXIMUM_LENGTH,
    IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'dbo'
  AND TABLE_NAME = 'DatabaseRestoreHistory'
ORDER BY ORDINAL_POSITION;
GO

PRINT 'RESTORE HISTORY SCHEMA COMPLETED.';
GO