/* ============================================================
   CECB DATABASE MONITORING SYSTEM
   USER ERROR LOG TABLE
   SQL SERVER 2022
   ============================================================ */

USE CECB_Monitoring;
GO

SET NOCOUNT ON;
GO

/* ============================================================
   1. CREATE USER ERROR LOG TABLE
   ============================================================ */

IF OBJECT_ID('dbo.UserErrorLog', 'U') IS NULL
BEGIN

    CREATE TABLE dbo.UserErrorLog
    (
        ErrorLogID BIGINT IDENTITY(1,1) NOT NULL,

        EventTime DATETIME2(3) NOT NULL,

        ErrorNumber INT NULL,

        Severity INT NULL,

        ErrorState INT NULL,

        UserName NVARCHAR(256) NULL,

        PCName NVARCHAR(256) NULL,

        DatabaseName NVARCHAR(256) NULL,

        ApplicationName NVARCHAR(256) NULL,

        SQLStatement NVARCHAR(MAX) NULL,

        ErrorMessage NVARCHAR(MAX) NULL,

        XELFileName NVARCHAR(512) NULL,

        XELFileOffset BIGINT NULL,

        CreatedDate DATETIME2(3)
            NOT NULL
            CONSTRAINT DF_UserErrorLog_CreatedDate
            DEFAULT SYSUTCDATETIME(),

        CONSTRAINT PK_UserErrorLog
            PRIMARY KEY CLUSTERED (ErrorLogID)
    );

    PRINT 'UserErrorLog table created successfully.';

END
ELSE
BEGIN

    PRINT 'UserErrorLog already exists. No changes made.';

END;
GO

/* ============================================================
   2. EVENT TIME INDEX
   ============================================================ */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = 'IX_UserErrorLog_EventTime'
      AND object_id = OBJECT_ID('dbo.UserErrorLog')
)
BEGIN

    CREATE INDEX IX_UserErrorLog_EventTime
    ON dbo.UserErrorLog(EventTime DESC);

END;
GO

/* ============================================================
   3. USER NAME INDEX
   ============================================================ */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = 'IX_UserErrorLog_UserName'
      AND object_id = OBJECT_ID('dbo.UserErrorLog')
)
BEGIN

    CREATE INDEX IX_UserErrorLog_UserName
    ON dbo.UserErrorLog(UserName);

END;
GO

/* ============================================================
   4. DATABASE NAME INDEX
   ============================================================ */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = 'IX_UserErrorLog_DatabaseName'
      AND object_id = OBJECT_ID('dbo.UserErrorLog')
)
BEGIN

    CREATE INDEX IX_UserErrorLog_DatabaseName
    ON dbo.UserErrorLog(DatabaseName);

END;
GO

/* ============================================================
   5. ERROR FILE DUPLICATE PREVENTION
   ============================================================ */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = 'UX_UserErrorLog_XELSource'
      AND object_id = OBJECT_ID('dbo.UserErrorLog')
)
BEGIN

    CREATE UNIQUE INDEX UX_UserErrorLog_XELSource
    ON dbo.UserErrorLog
    (
        XELFileName,
        XELFileOffset
    )
    WHERE XELFileName IS NOT NULL
      AND XELFileOffset IS NOT NULL;

END;
GO

/* ============================================================
   6. VERIFY TABLE STRUCTURE
   ============================================================ */

SELECT
    COLUMN_NAME,
    DATA_TYPE,
    CHARACTER_MAXIMUM_LENGTH,
    IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'dbo'
  AND TABLE_NAME = 'UserErrorLog'
ORDER BY ORDINAL_POSITION;
GO

PRINT 'USER ERROR LOG SCHEMA COMPLETED.';
GO