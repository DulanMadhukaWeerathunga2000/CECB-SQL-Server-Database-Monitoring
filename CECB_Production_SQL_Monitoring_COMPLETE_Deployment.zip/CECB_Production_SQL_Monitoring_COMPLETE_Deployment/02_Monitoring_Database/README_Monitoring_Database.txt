# CECB SQL SERVER DATABASE MONITORING SYSTEM
## 02 – MONITORING DATABASE FOLDER README

### 1. PURPOSE

This folder contains SQL scripts required to create and configure the central monitoring database.

The monitoring database stores user activities, SQL Server errors, database restore history and user-role mapping information.

### 2. FILE STRUCTURE

```text
02_Monitoring_Database
│
├── README_Monitoring_Database.txt
├── 00_Create_Database.sql
├── 01_Create_Tables.sql
├── 02_Seed_Role_Map.sql
├── 03_Create_RestoreHistory_Table.sql
├── 04_Create_UserErrorLog_Table.sql
└── 05_Create_UserRoleMap.sql
```

### 3. FILE DESCRIPTIONS

#### 00_Create_Database.sql

**Purpose:** Creates the `CECB_Monitoring` database if it does not already exist.

**Important:** Review the production data and file locations before execution. Database creation requires DBA approval.

#### 01_Create_Tables.sql

**Purpose:** Creates the main `UserActivityLog` table.

**Functions:**
- Stores SQL Server user activity.
- Records username and user role.
- Stores PC name and IP address.
- Records database, schema and table names.
- Stores activity type and SQL statement.
- Records success or failure status.
- Stores Audit file information.
- Prevents duplicate audit records using a unique index.

**Important:** `SequenceGroupID` must use the `UNIQUEIDENTIFIER` data type.

#### 02_Seed_Role_Map.sql

**Purpose:** Inserts or updates approved user-role mapping records.

**Example roles:**
- Admin
- Developer
- Management
- User

**Important:** The sample usernames are test examples. Confirm actual production SQL Server usernames with the DBA before using this script.

This script maps users to reporting roles. It does not grant SQL Server permissions.

#### 03_Create_RestoreHistory_Table.sql

**Purpose:** Creates the `DatabaseRestoreHistory` table.

**Functions:**
- Records database restore dates.
- Stores database names.
- Records backup file paths.
- Identifies the user who performed the restore.
- Stores restore status and remarks.
- Prevents duplicate restore history records.

#### 04_Create_UserErrorLog_Table.sql

**Purpose:** Creates the `UserErrorLog` table.

**Functions:**
- Stores SQL Server error events.
- Records error numbers and severity.
- Stores username and PC information.
- Records database and application information.
- Stores SQL statements and error messages.
- Maintains Extended Events file references.
- Prevents duplicate error records.

#### 05_Create_UserRoleMap.sql

**Purpose:** Creates the `UserRoleMap` table.

**Functions:**
- Stores usernames and reporting roles.
- Maintains active/inactive mapping status.
- Stores descriptions.
- Records creation and update dates.
- Enforces unique username mappings.

### 4. DATABASE TABLE OVERVIEW

| Table | Purpose |
|---|---|
| UserActivityLog | User activity monitoring |
| UserErrorLog | SQL Server error monitoring |
| DatabaseRestoreHistory | Database restore tracking |
| UserRoleMap | User and role mapping |

### 5. EXECUTION ORDER

Before executing any script, review the existing database and table structures.

Recommended order for a new, empty deployment:

1. `00_Create_Database.sql`
2. `01_Create_Tables.sql`
3. `03_Create_RestoreHistory_Table.sql`
4. `04_Create_UserErrorLog_Table.sql`
5. `05_Create_UserRoleMap.sql`
6. `02_Seed_Role_Map.sql`

**Important schema coordination:**

The current package has separate scripts for creating tables. Confirm that `01_Create_Tables.sql` creates only `UserActivityLog` and that the other scripts create their respective tables.

If the original version of `01_Create_Tables.sql` already creates all tables, do not execute the separate table creation scripts blindly. Reconcile the scripts first to prevent conflicting schemas.

### 6. REQUIRED PERMISSIONS

The deployment account must have DBA-approved permissions to:

- Create the monitoring database.
- Create tables and indexes.
- Create or update role mapping records.
- Create required database objects.

Do not grant additional permissions to production users without DBA approval.

### 7. VERIFICATION

After deployment, execute:

```sql
USE CECB_Monitoring;
GO

SELECT
    TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE'
ORDER BY TABLE_NAME;
GO
```

Check the number of records:

```sql
USE CECB_Monitoring;
GO

SELECT COUNT(*) AS TotalActivities
FROM dbo.UserActivityLog;

SELECT COUNT(*) AS TotalErrors
FROM dbo.UserErrorLog;

SELECT COUNT(*) AS TotalRestoreRecords
FROM dbo.DatabaseRestoreHistory;

SELECT COUNT(*) AS TotalRoleMappings
FROM dbo.UserRoleMap;
GO
```

Confirm that all four tables exist and have the expected columns and indexes.

### 8. TROUBLESHOOTING

**Database already exists:**
Check the existing database before attempting to create it again.

**Table already exists:**
Inspect its columns and indexes. Do not assume the existing schema matches the deployment package.

**Invalid column name:**
Compare the table structure with the relevant Stored Procedure.

**Duplicate key error:**
Check the unique indexes and existing records.

**Permission denied:**
Contact the DBA to review the deployment account permissions.

### 9. SECURITY NOTES

- Restrict access to the monitoring database.
- Do not expose SQL statements and error messages to unauthorized users.
- Confirm production usernames before inserting role mappings.
- Do not delete existing monitoring records without approval.
- Back up the monitoring database according to the approved backup plan.
- Keep production and test database environments separate.

### 10. EXPECTED RESULT

A central monitoring database capable of storing:

- User activity records.
- SQL Server error records.
- Database restore history.
- User-role mapping information.

This database provides the foundation for monitoring reports and automated collection.

**Project:** SQL Server Database Activity Monitoring, Backup and Restore Management System

**Organization:** Central Engineering Consultancy Bureau (CECB)

**Document:** Monitoring Database – Technical README

**Deployment Status:** Proposed – Pending Production Approval