/*
============================================================
CECB MONITORING DATABASE CREATION
============================================================

Creates CECB_Monitoring only if it does not exist.

Does not overwrite or drop an existing database.
============================================================
*/

USE master;
GO

SET NOCOUNT ON;

IF DB_ID(N'CECB_Monitoring') IS NULL
BEGIN
    PRINT 'Creating CECB_Monitoring...';

    CREATE DATABASE [CECB_Monitoring];

    PRINT 'CECB_Monitoring created successfully.';
END
ELSE
BEGIN
    PRINT 'CECB_Monitoring already exists.';
    PRINT 'No database changes were made.';
END;
GO