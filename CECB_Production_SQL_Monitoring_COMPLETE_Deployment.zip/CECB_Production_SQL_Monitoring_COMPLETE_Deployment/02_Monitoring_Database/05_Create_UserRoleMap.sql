/* ============================================================
   CECB DATABASE MONITORING SYSTEM
   USER ROLE MAPPING
   SQL SERVER 2022
   ============================================================ */

USE CECB_Monitoring;
GO

SET NOCOUNT ON;
GO

/* ============================================================
   1. CREATE USER ROLE MAP TABLE
   ============================================================ */

IF OBJECT_ID('dbo.UserRoleMap', 'U') IS NULL
BEGIN

    CREATE TABLE dbo.UserRoleMap
    (
        UserRoleMapID INT IDENTITY(1,1) NOT NULL,

        UserName NVARCHAR(256) NOT NULL,

        UserRole NVARCHAR(100) NOT NULL,

        Description NVARCHAR(500) NULL,

        IsActive BIT NOT NULL
            CONSTRAINT DF_UserRoleMap_IsActive
            DEFAULT (1),

        CreatedDate DATETIME2(3) NOT NULL
            CONSTRAINT DF_UserRoleMap_CreatedDate
            DEFAULT SYSUTCDATETIME(),

        UpdatedDate DATETIME2(3) NULL,

        CONSTRAINT PK_UserRoleMap
            PRIMARY KEY CLUSTERED (UserRoleMapID),

        CONSTRAINT UQ_UserRoleMap_UserName
            UNIQUE (UserName)
    );

    PRINT 'UserRoleMap table created successfully.';

END
ELSE
BEGIN

    PRINT 'UserRoleMap already exists. No changes made.';

END;
GO

/* ============================================================
   2. ROLE NAME INDEX
   ============================================================ */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = 'IX_UserRoleMap_UserRole'
      AND object_id = OBJECT_ID('dbo.UserRoleMap')
)
BEGIN

    CREATE INDEX IX_UserRoleMap_UserRole
    ON dbo.UserRoleMap(UserRole);

END;
GO

/* ============================================================
   3. VERIFY TABLE STRUCTURE
   ============================================================ */

SELECT
    COLUMN_NAME,
    DATA_TYPE,
    CHARACTER_MAXIMUM_LENGTH,
    IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'dbo'
  AND TABLE_NAME = 'UserRoleMap'
ORDER BY ORDINAL_POSITION;
GO

PRINT 'USER ROLE MAP SCHEMA COMPLETED.';
GO