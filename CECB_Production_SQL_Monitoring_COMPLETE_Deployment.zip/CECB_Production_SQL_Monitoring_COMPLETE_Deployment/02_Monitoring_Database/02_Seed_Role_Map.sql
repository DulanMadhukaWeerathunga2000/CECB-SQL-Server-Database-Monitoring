/* ============================================================
   CECB DATABASE MONITORING SYSTEM
   INITIAL USER ROLE MAPPING
   ============================================================ */

USE CECB_Monitoring;
GO

SET NOCOUNT ON;
GO

/* ============================================================
   1. ADMIN ROLE
   ============================================================ */

IF EXISTS
(
    SELECT 1
    FROM dbo.UserRoleMap
    WHERE UserName = N'admin'
)
BEGIN

    UPDATE dbo.UserRoleMap
    SET
        UserRole = N'Admin',
        Description = N'Database administration account',
        IsActive = 1,
        UpdatedDate = SYSUTCDATETIME()
    WHERE UserName = N'admin';

END
ELSE
BEGIN

    INSERT INTO dbo.UserRoleMap
    (
        UserName,
        UserRole,
        Description
    )
    VALUES
    (
        N'admin',
        N'Admin',
        N'Database administration account'
    );

END;
GO

/* ============================================================
   2. DEVELOPER ROLE
   ============================================================ */

IF EXISTS
(
    SELECT 1
    FROM dbo.UserRoleMap
    WHERE UserName = N'developer'
)
BEGIN

    UPDATE dbo.UserRoleMap
    SET
        UserRole = N'Developer',
        Description = N'Database development account',
        IsActive = 1,
        UpdatedDate = SYSUTCDATETIME()
    WHERE UserName = N'developer';

END
ELSE
BEGIN

    INSERT INTO dbo.UserRoleMap
    (
        UserName,
        UserRole,
        Description
    )
    VALUES
    (
        N'developer',
        N'Developer',
        N'Database development account'
    );

END;
GO

/* ============================================================
   3. MANAGEMENT ROLE
   ============================================================ */

IF EXISTS
(
    SELECT 1
    FROM dbo.UserRoleMap
    WHERE UserName = N'management'
)
BEGIN

    UPDATE dbo.UserRoleMap
    SET
        UserRole = N'Management',
        Description = N'Management reporting account',
        IsActive = 1,
        UpdatedDate = SYSUTCDATETIME()
    WHERE UserName = N'management';

END
ELSE
BEGIN

    INSERT INTO dbo.UserRoleMap
    (
        UserName,
        UserRole,
        Description
    )
    VALUES
    (
        N'management',
        N'Management',
        N'Management reporting account'
    );

END;
GO

/* ============================================================
   4. STANDARD USER ROLE
   ============================================================ */

IF EXISTS
(
    SELECT 1
    FROM dbo.UserRoleMap
    WHERE UserName = N'user'
)
BEGIN

    UPDATE dbo.UserRoleMap
    SET
        UserRole = N'User',
        Description = N'Standard database user account',
        IsActive = 1,
        UpdatedDate = SYSUTCDATETIME()
    WHERE UserName = N'user';

END
ELSE
BEGIN

    INSERT INTO dbo.UserRoleMap
    (
        UserName,
        UserRole,
        Description
    )
    VALUES
    (
        N'user',
        N'User',
        N'Standard database user account'
    );

END;
GO

/* ============================================================
   5. DISPLAY ROLE MAPPING
   ============================================================ */

SELECT
    UserRoleMapID,
    UserName,
    UserRole,
    Description,
    IsActive,
    CreatedDate,
    UpdatedDate
FROM dbo.UserRoleMap
ORDER BY UserRoleMapID;
GO

PRINT 'INITIAL USER ROLE MAPPING COMPLETED.';
GO