# CECB SQL SERVER DATABASE MONITORING SYSTEM
## 11 – DOCUMENTATION FOLDER README

### 1. PURPOSE

This folder contains the technical documentation required
for the proposed production deployment and ongoing
administration of the CECB SQL Server Database Monitoring,
Backup and Restore Management System.

The documentation is intended for:

- Project Manager (PM).
- Database Administrator (DBA).
- IT Administrators.
- System Support Staff.
- Authorized Technical Personnel.

The documents provide deployment checks, operational
guidance and database restoration procedures.

IMPORTANT:

The current project has been developed and tested using
a local test environment.

Deployment to the original CECB production SQL Server
is proposed future work and requires formal approval.

---

### 2. FILE STRUCTURE

11_Documentation
|
|-- README_Documentation.txt
|
|-- 01_Deployment_Checklist.txt
|
|-- 02_Restore_Procedure.txt

---

### 3. FILE DESCRIPTIONS

#### 01_Deployment_Checklist.txt

Purpose:

Provides a structured checklist for reviewing the system
before, during and after the proposed production deployment.

Main sections:

- Pre-deployment approval.
- SQL Server environment checks.
- Monitoring database preparation.
- SQL Server Audit configuration.
- Extended Events configuration.
- Collector installation.
- Reporting verification.
- Backup configuration.
- OneDrive synchronization.
- Windows Task Scheduler configuration.
- Post-deployment verification.
- Final DBA and PM acceptance.

#### 02_Restore_Procedure.txt

Purpose:

Provides the technical procedure for restoring databases
from Full and Differential backup files.

Main sections:

- Restore preparation.
- Backup file identification.
- Backup integrity verification.
- Logical file identification.
- Full database restore.
- Differential database restore.
- Post-restore verification.
- Restore history verification.
- Recovery precautions.
- Production recovery considerations.

---

### 4. RELATED PROJECT FOLDERS

This documentation refers to the following deployment folders:

01_Prerequisites
02_Monitoring_Database
03_SQL_Audit
04_Extended_Events
05_Collectors
06_Reports
07_Backup
08_Automation
09_Task_Scheduler
10_Verification

---

### 5. BACKUP STRATEGY

Approved proposed backup schedule:

Monthly Full Backup:
First day of every month at 1:00 AM.

Weekly Differential Backup:
Every Sunday at 2:00 AM.

Backup databases:

- CECB_ERP
- CECB_Monitoring
- CECB_System
- LeaveDB
- SP_USER_LOGIN

Differential backups depend on a compatible Full backup.

A Full backup must be available before the corresponding
Differential backup can be restored.

No transaction log backup schedule is currently included.

Therefore, point-in-time recovery for FULL recovery model
databases is not provided by the current backup plan.

---

### 6. SECURITY REQUIREMENTS

- Obtain formal production deployment approval.
- Use approved DBA and service accounts.
- Apply minimum required permissions.
- Protect SQL Audit files.
- Protect backup files.
- Restrict access to OneDrive backup folders.
- Do not expose SQL credentials in scripts.
- Do not overwrite existing production backups.
- Do not perform an unapproved production restore.

---

### 7. DOCUMENTATION USAGE

Before deployment:

Review the deployment checklist.

During deployment:

Follow the approved deployment sequence.

After deployment:

Execute the verification scripts.

For database recovery:

Follow the restore procedure and obtain DBA approval.

Record all deployment and restoration activities.

---

### 8. PROJECT STATUS

Project:

SQL Server Database Activity Monitoring, Backup and
Restore Management System

Organization:

Central Engineering Consultancy Bureau (CECB)

Current Development Status:

Local PC copy / test database implementation.

Production Deployment Status:

Proposed – Pending PM / DBA Approval.

This documentation does not authorize deployment
or modification of the original production databases.