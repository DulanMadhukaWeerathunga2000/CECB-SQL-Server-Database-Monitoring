# =========================================================
# CECB SQL SERVER DATABASE MONITORING SYSTEM
# ONEDRIVE BACKUP SYNCHRONIZATION
# =========================================================

$ErrorActionPreference = "Stop"

# Local backup folder
$SourceFolder = "C:\CECB_Monitoring\Backups"

# Replace with the approved production OneDrive path
$DestinationFolder = "C:\Users\REPLACE_WITH_WINDOWS_USER\OneDrive - CENTRAL ENGINEERING CONSULTANCY BUREAU\CECB_Database_Monitoring\Database_Backups"

# Log folder
$LogFolder = "C:\CECB_Production_SQL_Monitoring_COMPLETE_Deployment\Logs"

# Create log folder if required
if (!(Test-Path -LiteralPath $LogFolder)) {
    New-Item -ItemType Directory -Path $LogFolder -Force | Out-Null
}

$TimeStamp = Get-Date -Format "yyyyMMdd_HHmmss"

$LogFile = Join-Path $LogFolder "OneDrive_Sync_$TimeStamp.log"

"========================================" | Out-File $LogFile
"CECB ONEDRIVE BACKUP SYNCHRONIZATION" | Out-File $LogFile -Append
"Started: $(Get-Date)" | Out-File $LogFile -Append
"========================================" | Out-File $LogFile -Append

try {

    # Check source folder
    if (!(Test-Path -LiteralPath $SourceFolder)) {
        throw "Source backup folder does not exist: $SourceFolder"
    }

    # Check destination configuration
    if ($DestinationFolder -match "REPLACE_WITH") {
        throw "OneDrive destination path has not been configured."
    }

    # Check OneDrive destination
    if (!(Test-Path -LiteralPath $DestinationFolder)) {
        throw "OneDrive destination folder does not exist: $DestinationFolder"
    }

    # Find backup files
    $BackupFiles = Get-ChildItem `
        -LiteralPath $SourceFolder `
        -Filter "*.bak" `
        -File

    if ($BackupFiles.Count -eq 0) {
        throw "No .bak backup files found in source folder."
    }

    "Source: $SourceFolder" | Out-File $LogFile -Append
    "Destination: $DestinationFolder" | Out-File $LogFile -Append
    "Backup files found: $($BackupFiles.Count)" | Out-File $LogFile -Append

    # Copy backup files without deleting existing files
    & robocopy `
        $SourceFolder `
        $DestinationFolder `
        "*.bak" `
        /E `
        /XO `
        /Z `
        /R:3 `
        /W:5 `
        /COPY:DAT `
        /DCOPY:DAT `
        /NP `
        /LOG+:$LogFile

    $RobocopyExitCode = $LASTEXITCODE

    # Robocopy exit codes below 8 indicate no fatal copy error
    if ($RobocopyExitCode -ge 8) {
        throw "Robocopy failed with exit code $RobocopyExitCode."
    }

    "Robocopy exit code: $RobocopyExitCode" | Out-File $LogFile -Append
    "Local-to-OneDrive folder copy completed." | Out-File $LogFile -Append

    # Confirm destination contains backup files
    $DestinationFiles = Get-ChildItem `
        -LiteralPath $DestinationFolder `
        -Filter "*.bak" `
        -File

    "Destination backup file count: $($DestinationFiles.Count)" |
        Out-File $LogFile -Append

    "Completed: $(Get-Date)" | Out-File $LogFile -Append

    exit 0

}
catch {

    "ERROR: $($_.Exception.Message)" | Out-File $LogFile -Append
    "Failed: $(Get-Date)" | Out-File $LogFile -Append

    exit 1
}