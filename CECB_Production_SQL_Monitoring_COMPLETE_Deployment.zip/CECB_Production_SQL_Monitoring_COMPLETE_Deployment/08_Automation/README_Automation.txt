# CECB SQL SERVER DATABASE MONITORING SYSTEM
## 08 – AUTOMATION FOLDER README

### 1. PURPOSE

This folder contains automation scripts used to execute SQL Server database backup operations and synchronize backup files with the approved OneDrive destination.

The automation component reduces manual backup operations and supports regular database backup management.

Main functions:

- Monthly Full Backup automation.
- Weekly Differential Backup automation.
- OneDrive backup folder synchronization.
- Backup execution logging.
- Backup process error handling.

---

### 2. FILE STRUCTURE

08_Automation
│
├── README_Automation.txt
├── 01_Run_Monthly_Full_Backup.bat
├── 02_Run_Weekly_Differential_Backup.bat
└── 03_Sync_To_OneDrive.ps1

---

### 3. FILE DESCRIPTIONS

#### 01_Run_Monthly_Full_Backup.bat

Purpose:

Automatically executes the Monthly Full Backup SQL script.

Main functions:

- Locates the Monthly Full Backup SQL file.
- Checks sqlcmd availability.
- Connects to the approved SQL Server instance.
- Executes the Full Backup script.
- Records execution output.
- Calls the OneDrive synchronization script after successful backup.

SQL script:

07_Backup\01_Monthly_Full_Backup.sql

Proposed schedule:

First day of every month at 1:00 AM.

Output:

Monthly backup execution log.

#### 02_Run_Weekly_Differential_Backup.bat

Purpose:

Automatically executes the Weekly Differential Backup SQL script.

Main functions:

- Locates the Weekly Differential Backup SQL file.
- Checks sqlcmd availability.
- Connects to the approved SQL Server instance.
- Executes the Differential Backup script.
- Records execution output.
- Calls the OneDrive synchronization script after successful backup.

SQL script:

07_Backup\02_Weekly_Differential_Backup.sql

Proposed schedule:

Every Sunday at 2:00 AM.

Output:

Weekly differential backup execution log.

#### 03_Sync_To_OneDrive.ps1

Purpose:

Copies local SQL Server backup files to the approved OneDrive synchronization folder.

Main functions:

- Checks the local backup directory.
- Checks the OneDrive destination.
- Identifies .bak backup files.
- Copies backup files using Robocopy.
- Avoids overwriting newer destination files.
- Does not delete existing backup files.
- Records synchronization output.
- Reports copy errors.

Source directory:

C:\CECB_Monitoring\Backups

Proposed destination:

OneDrive\CECB_Database_Monitoring\Database_Backups

IMPORTANT:

The script copies files into the local OneDrive synchronization folder. OneDrive must subsequently upload the files to cloud storage.

---

### 4. AUTOMATION WORKFLOW

Monthly Full Backup:

1. Windows Task Scheduler starts the monthly batch file.
2. The batch file checks required files and sqlcmd.
3. SQL Server executes the Full Backup script.
4. Backup files are created in the backup directory.
5. The OneDrive synchronization script is executed.
6. Backup files are copied to the OneDrive folder.
7. Execution logs are generated.

Weekly Differential Backup:

1. Windows Task Scheduler starts the weekly batch file.
2. The batch file checks required files and sqlcmd.
3. SQL Server executes the Differential Backup script.
4. Differential backup files are created.
5. The OneDrive synchronization script is executed.
6. Backup files are copied to the OneDrive folder.
7. Execution logs are generated.

---

### 5. AUTOMATION SCHEDULE

Monthly Full Backup:

Frequency: Monthly
Day: First day of the month
Time: 1:00 AM

Weekly Differential Backup:

Frequency: Weekly
Day: Sunday
Time: 2:00 AM

The schedules will be configured through Windows Task Scheduler.

SQL Server Express does not provide SQL Server Agent scheduling functionality.

---

### 6. CONFIGURATION REQUIREMENTS

Before deployment, review the following settings:

1. Production SQL Server instance name.
2. Deployment folder location.
3. Monthly Full Backup SQL file path.
4. Weekly Differential Backup SQL file path.
5. Local backup directory.
6. OneDrive destination directory.
7. Windows Task Scheduler account.
8. SQL Server authentication permissions.

Replace:

REPLACE_WITH_PRODUCTION_SQL_INSTANCE

With the approved SQL Server instance name.

Replace:

REPLACE_WITH_WINDOWS_USER

With the appropriate Windows account folder name.

The configured paths must match the actual production environment.

---

### 7. PERMISSIONS AND REQUIREMENTS

Required components:

- SQL Server Management Studio or sqlcmd.
- Windows PowerShell.
- Windows Task Scheduler.
- Robocopy.
- OneDrive desktop synchronization client.

Required permissions:

SQL Server Database Engine service account:

- Read access to SQL backup scripts where applicable.
- Write access to the SQL backup directory.

Windows Task Scheduler account:

- Read and execute access to automation scripts.
- Required SQL Server database permissions.
- Access to the local backup directory.
- Access to the OneDrive synchronization directory.

OneDrive:

- Must be configured and signed in.
- Must have access to the destination folder.
- Must have sufficient cloud storage.

---

### 8. LOG MANAGEMENT

Automation logs are stored in:

C:\CECB_Production_SQL_Monitoring_COMPLETE_Deployment\Logs

Expected log files:

Monthly_Full_Backup_YYYYMMDD_HHMMSS.log

Weekly_Differential_Backup_YYYYMMDD_HHMMSS.log

OneDrive_Sync_YYYYMMDD_HHMMSS.log

Logs help identify:

- Successful backup operations.
- Failed backup operations.
- SQL Server connection errors.
- Missing files.
- OneDrive copy errors.
- Automation execution results.

---

### 9. EXECUTION VERIFICATION

After executing the monthly or weekly automation scripts:

1. Check the generated log file.
2. Confirm the SQL backup operation completed successfully.
3. Confirm backup files exist in the local backup directory.
4. Confirm backup files are present in the OneDrive destination folder.
5. Check OneDrive synchronization status.
6. Verify backup history using:

07_Backup\03_Verify_Backup_History.sql

---

### 10. TROUBLESHOOTING

sqlcmd not found:

Install or configure the SQL Server command-line utilities and verify PATH.

SQL Server connection failed:

Check SQL Server instance name and Windows account permissions.

Backup script not found:

Check the deployment folder structure and SQL file paths.

Access denied:

Review Windows folder permissions and SQL Server service account permissions.

OneDrive destination not found:

Check the configured OneDrive folder path.

OneDrive synchronization incomplete:

Check whether the OneDrive client is running and signed in.

Robocopy failure:

Review the synchronization log and destination permissions.

---

### 11. SECURITY AND OPERATIONAL NOTES

- Do not store SQL passwords directly in batch files.
- Use approved Windows authentication.
- Restrict access to backup files.
- Do not delete existing production backups.
- Do not overwrite the existing production backup process before approval.
- Monitor OneDrive synchronization status.
- Review automation logs regularly.
- Confirm successful backup operations.
- Test the scripts in an approved test environment before production deployment.

---

### 12. EXPECTED RESULT

The automation component should provide:

- Automated Monthly Full Backups.
- Automated Weekly Differential Backups.
- Automated backup file copying to OneDrive.
- Backup execution logs.
- Synchronization logs.
- Error reporting.
- Reduced manual backup operations.

The automation component supports reliable database backup management and disaster recovery.

Project: SQL Server Database Activity Monitoring, Backup and Restore Management System

Organization: Central Engineering Consultancy Bureau (CECB)

Document: Automation – Technical README

Deployment Status: Proposed – Pending Production Approval