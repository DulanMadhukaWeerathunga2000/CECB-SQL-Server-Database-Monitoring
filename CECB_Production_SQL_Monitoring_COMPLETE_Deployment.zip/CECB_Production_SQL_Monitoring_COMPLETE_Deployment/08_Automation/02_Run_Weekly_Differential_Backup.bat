@echo off
SETLOCAL ENABLEEXTENSIONS

REM =========================================================
REM CECB SQL SERVER DATABASE MONITORING SYSTEM
REM WEEKLY DIFFERENTIAL BACKUP AUTOMATION
REM =========================================================

SET "BASE_DIR=C:\CECB_Production_SQL_Monitoring_COMPLETE_Deployment"
SET "SQL_FILE=%BASE_DIR%\07_Backup\02_Weekly_Differential_Backup.sql"
SET "LOG_DIR=%BASE_DIR%\Logs"
SET "SQL_SERVER=REPLACE_WITH_PRODUCTION_SQL_INSTANCE"
SET "SYNC_SCRIPT=%BASE_DIR%\08_Automation\03_Sync_To_OneDrive.ps1"

IF NOT EXIST "%LOG_DIR%" MKDIR "%LOG_DIR%"

FOR /F %%A IN ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') DO SET "RUN_TIME=%%A"

SET "LOG_FILE=%LOG_DIR%\Weekly_Differential_Backup_%RUN_TIME%.log"

ECHO ======================================== > "%LOG_FILE%"
ECHO CECB WEEKLY DIFFERENTIAL BACKUP >> "%LOG_FILE%"
ECHO Started: %DATE% %TIME% >> "%LOG_FILE%"
ECHO ======================================== >> "%LOG_FILE%"

IF NOT EXIST "%SQL_FILE%" (
    ECHO ERROR: SQL file not found. >> "%LOG_FILE%"
    EXIT /B 1
)

WHERE sqlcmd >NUL 2>&1

IF ERRORLEVEL 1 (
    ECHO ERROR: sqlcmd not found. >> "%LOG_FILE%"
    EXIT /B 1
)

sqlcmd -S "%SQL_SERVER%" -d master -E -b -r1 -i "%SQL_FILE%" >> "%LOG_FILE%" 2>&1

IF ERRORLEVEL 1 (
    ECHO ERROR: Weekly Differential Backup failed. >> "%LOG_FILE%"
    EXIT /B 1
)

ECHO Weekly Differential Backup completed successfully. >> "%LOG_FILE%"

IF NOT EXIST "%SYNC_SCRIPT%" (
    ECHO ERROR: OneDrive sync script not found. >> "%LOG_FILE%"
    EXIT /B 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SYNC_SCRIPT%" >> "%LOG_FILE%" 2>&1

IF ERRORLEVEL 1 (
    ECHO WARNING: Backup completed but OneDrive copy failed. >> "%LOG_FILE%"
    EXIT /B 1
)

ECHO OneDrive copy process completed. >> "%LOG_FILE%"
ECHO Finished: %DATE% %TIME% >> "%LOG_FILE%"

EXIT /B 0