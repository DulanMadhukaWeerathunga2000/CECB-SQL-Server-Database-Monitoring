# CECB SQL SERVER DATABASE MONITORING SYSTEM
## 07 – BACKUP FOLDER README

### 1. PURPOSE

This folder contains SQL Server database backup scripts designed to protect CECB databases and support database recovery and disaster recovery operations.

The backup strategy uses:

- Monthly Full Backups.
- Weekly Differential Backups.
- Backup History Verification.

The main objective is to maintain reliable database backup copies and support business continuity.

---

### 2. FILE STRUCTURE

07_Backup
│
├── README_Backup.txt
├── 01_Monthly_Full_Backup.sql
├── 02_Weekly_Differential_Backup.sql
└── 03_Verify_Backup_History.sql

---

### 3. FILE DESCRIPTIONS

#### 01_Monthly_Full_Backup.sql

Purpose:

Creates full backups of the approved CECB databases.

Schedule:

- First day of every month.
- 1:00 AM.

Main functions:

- Creates complete database backups.
- Uses CHECKSUM during backup.
- Generates timestamp-based backup filenames.
- Processes the approved database list.
- Displays backup execution progress.
- Reports backup errors.

Output:

Full database backup files with .bak extension.

#### 02_Weekly_Differential_Backup.sql

Purpose:

Creates differential backups of the approved CECB databases.

Schedule:

- Every Sunday.
- 2:00 AM.

Main functions:

- Backs up changes made since the latest Full Backup.
- Uses CHECKSUM during backup.
- Generates timestamp-based backup filenames.
- Processes the approved database list.
- Displays backup execution progress.
- Reports backup errors.

Output:

Differential database backup files with .bak extension.

IMPORTANT:

A successful regular Full Backup is required before creating a Differential Backup.

#### 03_Verify_Backup_History.sql

Purpose:

Checks SQL Server backup history stored in the msdb database.

Main functions:

- Displays database names.
- Identifies Full and Differential backup types.
- Displays backup start time.
- Displays backup completion time.
- Displays backup size in MB.
- Displays physical backup file location.
- Shows backup history in descending date order.

Output:

Backup history verification results in SSMS.

---

### 4. DATABASE BACKUP CONFIGURATION

The proposed database configuration is:

Database Name       Recovery Model
----------------------------------
CECB_ERP            FULL
CECB_Monitoring      SIMPLE
CECB_System          SIMPLE
LeaveDB              FULL
SP_USER_LOGIN        FULL

The recovery model of each production database must be verified by the DBA before deployment.

---

### 5. BACKUP SCHEDULE

Monthly Full Backup:

- Frequency: Monthly.
- Day: First day of the month.
- Time: 1:00 AM.

Weekly Differential Backup:

- Frequency: Weekly.
- Day: Sunday.
- Time: 2:00 AM.

Differential backups contain changes since the latest Full Backup.

The first Full Backup must be completed successfully before the first Differential Backup.

---

### 6. BACKUP STORAGE

Proposed local backup directory:

C:\CECB_Monitoring\Backups

Proposed OneDrive destination:

OneDrive\CECB_Database_Monitoring\Database_Backups

The production backup directory and OneDrive destination must be confirmed before deployment.

The SQL Server Database Engine service account must have the required write permissions to the backup directory.

---

### 7. EXECUTION REQUIREMENTS

Before executing backup scripts:

1. Confirm the SQL Server instance.
2. Confirm the database names.
3. Verify database recovery models.
4. Confirm the backup destination folder exists.
5. Ensure sufficient disk space is available.
6. Ensure SQL Server service account permissions.
7. Confirm that a Full Backup has completed successfully.
8. Obtain DBA approval before production execution.

---

### 8. EXECUTION ORDER

Execute the backup scripts in the following order:

1. 01_Monthly_Full_Backup.sql
2. 02_Weekly_Differential_Backup.sql
3. 03_Verify_Backup_History.sql

IMPORTANT:

The Monthly Full Backup script must be executed successfully before the first Weekly Differential Backup.

The verification script can be executed after backup operations to review the recorded backup history.

---

### 9. HOW TO EXECUTE BACKUP SCRIPTS

#### Monthly Full Backup

1. Open SQL Server Management Studio.
2. Connect to the approved SQL Server instance.
3. Open 01_Monthly_Full_Backup.sql.
4. Confirm the backup directory.
5. Execute the script.
6. Review the Messages tab.
7. Confirm successful backup completion.

#### Weekly Differential Backup

1. Open 02_Weekly_Differential_Backup.sql.
2. Confirm the backup directory.
3. Confirm that a Full Backup exists.
4. Execute the script.
5. Review the Messages tab.
6. Confirm successful backup completion.

#### Backup History Verification

1. Open 03_Verify_Backup_History.sql.
2. Execute the script.
3. Review the Results tab.
4. Check database names.
5. Check backup types.
6. Check backup dates and file locations.

---

### 10. BACKUP VERIFICATION

The backup history verification script uses:

- msdb.dbo.backupset
- msdb.dbo.backupmediafamily

These system tables contain SQL Server backup history and backup media information.

For additional backup integrity checking, use:

RESTORE VERIFYONLY
FROM DISK = 'C:\CECB_Monitoring\Backups\Your_Backup_File.bak'
WITH CHECKSUM;

Note:

RESTORE VERIFYONLY does not replace an actual database restore test.

An isolated test restore must be performed to confirm that the backup can be restored successfully.

---

### 11. RESTORE REQUIREMENTS

To restore a database using a Full Backup and Differential Backup:

1. Identify the correct Full Backup.
2. Identify the matching Differential Backup.
3. Restore the Full Backup using NORECOVERY.
4. Restore the matching Differential Backup using RECOVERY.
5. Verify database availability.
6. Perform database integrity checks.
7. Confirm application connectivity.

The Differential Backup must belong to the same Full Backup differential base.

---

### 12. TROUBLESHOOTING

Backup directory not found:

Check whether the backup directory exists.

Access denied:

Check SQL Server Database Engine service account permissions.

Insufficient disk space:

Check available storage before executing backups.

Differential backup failure:

Confirm that a valid Full Backup exists and that the differential base is compatible.

Backup history not displayed:

Check whether backup operations completed successfully and whether msdb backup history is available.

Database not found:

Verify database names and database availability.

---

### 13. SECURITY AND BACKUP NOTES

- Restrict access to backup folders.
- Protect backup files from unauthorized modification.
- Do not delete existing production backups.
- Keep the existing production backup process until the new process is validated and approved.
- Monitor available disk space.
- Verify OneDrive synchronization status.
- Maintain a separate restore testing procedure.
- Protect backup files according to CECB security policies.
- FULL recovery model databases may require additional Transaction Log Backup planning for point-in-time recovery.

---

### 14. EXPECTED RESULT

The backup component should provide:

- Monthly Full Backups.
- Weekly Differential Backups.
- Timestamp-based backup files.
- Backup history verification.
- Backup integrity checking support.
- OneDrive backup synchronization support.
- A reliable foundation for database recovery.

The backup component supports database protection, disaster recovery and business continuity.

Project: SQL Server Database Activity Monitoring, Backup and Restore Management System

Organization: Central Engineering Consultancy Bureau (CECB)

Document: Backup – Technical README

Deployment Status: Proposed – Pending Production Approval