USE msdb;
GO

/* =========================================================
   CECB SQL SERVER DATABASE MONITORING SYSTEM

   FILE: 03_Verify_Backup_History.sql

   PURPOSE:
   Verify SQL Server Backup History

   BACKUP TYPES:
   FULL
   DIFFERENTIAL

   ========================================================= */

SET NOCOUNT ON;

SELECT
    B.database_name AS DatabaseName,

    CASE
        WHEN B.type = 'D' THEN 'FULL'
        WHEN B.type = 'I' THEN 'DIFFERENTIAL'
        ELSE B.type
    END AS BackupType,

    B.backup_start_date AS BackupStartTime,
    B.backup_finish_date AS BackupFinishTime,

    CAST(
        B.backup_size / 1024.0 / 1024.0
        AS DECIMAL(18,2)
    ) AS BackupSizeMB,

    M.physical_device_name AS BackupLocation

FROM dbo.backupset B

INNER JOIN dbo.backupmediafamily M
    ON B.media_set_id = M.media_set_id

WHERE B.database_name IN
(
    'CECB_ERP',
    'CECB_Monitoring',
    'CECB_System',
    'LeaveDB',
    'SP_USER_LOGIN'
)

ORDER BY B.backup_finish_date DESC;
GO

PRINT 'Backup history verification completed.';
GO