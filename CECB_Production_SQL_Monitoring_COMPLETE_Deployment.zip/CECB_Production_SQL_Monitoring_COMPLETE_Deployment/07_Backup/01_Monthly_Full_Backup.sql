USE master;
GO

/* =========================================================
   CECB SQL SERVER DATABASE MONITORING SYSTEM

   FILE: 01_Monthly_Full_Backup.sql

   PURPOSE:
   Monthly Full Database Backup

   PROPOSED SCHEDULE:
   First day of every month - 01:00 AM

   IMPORTANT:
   Production execution requires DBA approval.
   ========================================================= */

SET NOCOUNT ON;

DECLARE @BackupRoot NVARCHAR(4000) =
    N'C:\CECB_Monitoring\Backups';

DECLARE @BackupFile NVARCHAR(4000);
DECLARE @DatabaseName SYSNAME;
DECLARE @SQL NVARCHAR(MAX);
DECLARE @TimeStamp VARCHAR(30);

DECLARE @Databases TABLE
(
    DatabaseName SYSNAME PRIMARY KEY
);

INSERT INTO @Databases (DatabaseName)
VALUES
    (N'CECB_ERP'),
    (N'CECB_Monitoring'),
    (N'CECB_System'),
    (N'LeaveDB'),
    (N'SP_USER_LOGIN');

-- Generate timestamp
SET @TimeStamp =
    CONVERT(VARCHAR(8), GETDATE(), 112)
    + '_'
    + REPLACE(CONVERT(VARCHAR(8), GETDATE(), 108), ':', '');

PRINT '========================================';
PRINT 'CECB MONTHLY FULL BACKUP STARTED';
PRINT '========================================';

PRINT 'Backup location: ' + @BackupRoot;

-- Check database availability
IF EXISTS
(
    SELECT 1
    FROM @Databases D
    LEFT JOIN sys.databases S
        ON S.name = D.DatabaseName
    WHERE S.name IS NULL
       OR S.state_desc <> 'ONLINE'
)
BEGIN
    THROW 50001,
        'One or more required databases are missing or offline.',
        1;
END;

-- Process each database
DECLARE BackupCursor CURSOR LOCAL FAST_FORWARD
FOR
    SELECT DatabaseName
    FROM @Databases
    ORDER BY DatabaseName;

OPEN BackupCursor;

FETCH NEXT FROM BackupCursor INTO @DatabaseName;

WHILE @@FETCH_STATUS = 0
BEGIN
    BEGIN TRY

        SET @BackupFile =
            @BackupRoot
            + N'\'
            + @DatabaseName
            + N'_FULL_'
            + @TimeStamp
            + N'.bak';

        PRINT '----------------------------------------';
        PRINT 'Starting Full Backup: ' + @DatabaseName;
        PRINT 'Backup File: ' + @BackupFile;

        SET @SQL =
            N'BACKUP DATABASE '
            + QUOTENAME(@DatabaseName)
            + N' TO DISK = N'''
            + REPLACE(@BackupFile, '''', '''''')
            + N''' WITH CHECKSUM, STATS = 10;';

        EXEC sys.sp_executesql @SQL;

        PRINT 'SUCCESS: ' + @DatabaseName;

    END TRY
    BEGIN CATCH

        PRINT 'BACKUP FAILED: ' + @DatabaseName;
        PRINT ERROR_MESSAGE();

        CLOSE BackupCursor;
        DEALLOCATE BackupCursor;

        THROW;

    END CATCH;

    FETCH NEXT FROM BackupCursor INTO @DatabaseName;
END;

CLOSE BackupCursor;
DEALLOCATE BackupCursor;

PRINT '========================================';
PRINT 'ALL MONTHLY FULL BACKUPS COMPLETED';
PRINT '========================================';
GO