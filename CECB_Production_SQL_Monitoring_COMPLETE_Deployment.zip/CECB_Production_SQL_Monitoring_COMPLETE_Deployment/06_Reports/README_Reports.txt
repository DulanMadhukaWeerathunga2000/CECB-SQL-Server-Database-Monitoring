# CECB SQL SERVER DATABASE MONITORING SYSTEM
## 06 – REPORTS FOLDER README

### 1. PURPOSE

This folder contains SQL Server reporting scripts used to generate database activity, user activity, error and monitoring summary reports.

The reports use collected information stored in the `CECB_Monitoring` database.

The main objective is to provide management and technical staff with clear information about database usage, user activities and system errors.

---

### 2. FILE STRUCTURE

```text
06_Reports
│
├── README_Reports.txt
├── 01_Report_Views.sql
├── 02_Verify_Report_Views.sql
├── 03_Daily_Activity_Report.sql
└── 04_User_Activity_Details_Report.sql
```

---

### 3. FILE DESCRIPTIONS

#### 01_Report_Views.sql

**Purpose:**

Creates or updates SQL Server views for monitoring and reporting.

**Expected views:**

- `vw_DashboardSummary`
- `vw_DashboardUserSummary`
- `vw_DashboardDateSummary`
- `vw_DashboardErrorSummary`
- `vw_DashboardRecentActivity`
- `vw_CombinedMonitoringReport`
- `vw_ErrorDetailsReport`
- `vw_UserActivityReport`
- `vw_DatabaseActivityReport`
- `vw_MonthlyActivityReport`

**Main functions:**

- Provides overall activity summaries.
- Summarizes activities by user.
- Summarizes activities by date.
- Displays error summaries.
- Shows recent database activities.
- Combines monitoring records.
- Provides detailed error information.
- Summarizes database activity.
- Provides monthly activity statistics.

**Output:** SQL Server reporting views.

#### 02_Verify_Report_Views.sql

**Purpose:**

Checks whether the reporting views have been created successfully.

**Main functions:**

- Checks the availability of reporting views.
- Executes SELECT queries against the views.
- Identifies missing views or schema-related errors.
- Helps verify report availability.

**Output:** Verification results in SSMS.

#### 03_Daily_Activity_Report.sql

**Purpose:**

Generates a daily database activity summary.

**Report information includes:**

- Activity date.
- Username.
- User role.
- PC name.
- IP address.
- Database name.
- Activity type.
- Success or failure status.
- Total activity count.

**Output:** Daily activity summary displayed in SSMS.

#### 04_User_Activity_Details_Report.sql

**Purpose:**

Generates detailed user activity records for a selected reporting period.

**Report information includes:**

- Event date and time.
- Username.
- User role.
- PC name.
- IP address.
- Database name.
- Schema name.
- Table name.
- Activity type.
- SQL statement.
- Execution status.
- Application information.

**Output:** Detailed user activity report displayed in SSMS.

---

### 4. EXECUTION REQUIREMENTS

Before executing the reporting scripts:

1. Confirm that `CECB_Monitoring` exists.
2. Confirm that the required monitoring tables exist.
3. Confirm that the collector procedures have been configured.
4. Confirm that the reporting views reference valid table columns.
5. Confirm that the deployment account has the required database permissions.
6. Obtain DBA approval before production execution.

---

### 5. EXECUTION ORDER

Execute the reporting scripts in the following order:

1. `01_Report_Views.sql`
2. `02_Verify_Report_Views.sql`
3. `03_Daily_Activity_Report.sql`
4. `04_User_Activity_Details_Report.sql`

The reporting views should be created before running the verification script.

---

### 6. HOW TO GENERATE REPORTS

#### Daily Activity Report

1. Open SQL Server Management Studio.
2. Connect to the approved SQL Server instance.
3. Open `03_Daily_Activity_Report.sql`.
4. Review the reporting date configuration.
5. Execute the script.
6. Review the Results tab.
7. Export the results if required.

#### Detailed User Activity Report

1. Open `04_User_Activity_Details_Report.sql`.
2. Review the start and end date configuration.
3. Execute the script.
4. Review the returned activity records.
5. Export the results for further analysis if required.

---

### 7. REPORT VERIFICATION

Check the available reporting views:

```sql
USE CECB_Monitoring;
GO

SELECT
    TABLE_SCHEMA,
    TABLE_NAME
FROM INFORMATION_SCHEMA.VIEWS
ORDER BY TABLE_NAME;
GO
```

Check dashboard summary:

```sql
SELECT *
FROM dbo.vw_DashboardSummary;
GO
```

Check user summary:

```sql
SELECT *
FROM dbo.vw_DashboardUserSummary;
GO
```

Check monthly activity:

```sql
SELECT *
FROM dbo.vw_MonthlyActivityReport;
GO
```

Check recent activity:

```sql
SELECT *
FROM dbo.vw_DashboardRecentActivity;
GO
```

---

### 8. TROUBLESHOOTING

**View does not exist:**

Execute `01_Report_Views.sql` and check for errors.

**Invalid column name:**

Compare the reporting view with the actual monitoring table schema.

**No records returned:**

Check whether the collector procedures have collected records.

**Incorrect date range:**

Review the date filters in the corresponding report script.

**Permission denied:**

Ask the DBA to review the reporting account permissions.

---

### 9. SECURITY AND REPORTING NOTES

- Restrict access to monitoring reports according to CECB policy.
- Do not expose sensitive SQL statements to unauthorized users.
- Verify user-role mapping before management reporting.
- Use approved reporting date ranges.
- Retain exported reports according to organizational policy.
- Validate report accuracy before submitting reports to management.
- Do not modify source monitoring records through reporting scripts.

---

### 10. EXPECTED RESULT

The reporting component should provide:

- Daily database activity reports.
- Detailed user activity reports.
- User-wise activity summaries.
- Database-wise activity summaries.
- SQL Server error reports.
- Monthly activity reports.
- Dashboard-ready monitoring information.

The reports support database administration, security monitoring and management review.

**Project:** SQL Server Database Activity Monitoring, Backup and Restore Management System

**Organization:** Central Engineering Consultancy Bureau (CECB)

**Document:** Reports – Technical README

**Deployment Status:** Proposed – Pending Production Approval