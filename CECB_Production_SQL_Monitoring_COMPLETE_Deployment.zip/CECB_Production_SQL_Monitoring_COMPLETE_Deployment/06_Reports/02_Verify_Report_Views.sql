USE CECB_Monitoring;
GO

/* =========================================================
   VERIFY REPORTING VIEWS
   ========================================================= */

DECLARE @ExpectedViews TABLE
(
    ViewName SYSNAME
);

INSERT INTO @ExpectedViews (ViewName)
VALUES
('vw_DashboardSummary'),
('vw_DashboardUserSummary'),
('vw_DashboardDateSummary'),
('vw_DashboardErrorSummary'),
('vw_DashboardRecentActivity'),
('vw_CombinedMonitoringReport'),
('vw_ErrorDetailsReport'),
('vw_UserActivityReport'),
('vw_DatabaseActivityReport'),
('vw_MonthlyActivityReport');

SELECT
    E.ViewName,
    CASE
        WHEN V.object_id IS NOT NULL THEN 'AVAILABLE'
        ELSE 'MISSING'
    END AS ViewStatus
FROM @ExpectedViews E
LEFT JOIN sys.views V
    ON V.name = E.ViewName
ORDER BY E.ViewName;
GO

-- Test each reporting view
SELECT * FROM dbo.vw_DashboardSummary;
GO

SELECT TOP (20) *
FROM dbo.vw_DashboardUserSummary
ORDER BY TotalActivities DESC;
GO

SELECT TOP (30) *
FROM dbo.vw_DashboardDateSummary
ORDER BY ActivityDate DESC;
GO

SELECT TOP (30) *
FROM dbo.vw_DashboardErrorSummary
ORDER BY ErrorDate DESC;
GO

SELECT TOP (20) *
FROM dbo.vw_DashboardRecentActivity;
GO

SELECT TOP (50) *
FROM dbo.vw_CombinedMonitoringReport
ORDER BY EventTime DESC;
GO

SELECT TOP (50) *
FROM dbo.vw_ErrorDetailsReport
ORDER BY EventTime DESC;
GO

SELECT TOP (50) *
FROM dbo.vw_UserActivityReport
ORDER BY EventTime DESC;
GO

SELECT *
FROM dbo.vw_DatabaseActivityReport
ORDER BY TotalActivities DESC;
GO

SELECT *
FROM dbo.vw_MonthlyActivityReport
ORDER BY ActivityYear DESC, ActivityMonth DESC;
GO

PRINT 'Reporting view verification completed.';
GO