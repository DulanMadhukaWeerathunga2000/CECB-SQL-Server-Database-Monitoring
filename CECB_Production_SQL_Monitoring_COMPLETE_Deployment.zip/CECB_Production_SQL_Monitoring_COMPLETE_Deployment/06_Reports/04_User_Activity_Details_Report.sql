USE CECB_Monitoring;
GO

/* =========================================================
   DETAILED USER ACTIVITY REPORT
   ========================================================= */

DECLARE @StartDate DATE = '2026-11-01';
DECLARE @EndDate   DATE = CAST(GETDATE() AS DATE);

-- Optional user filter
DECLARE @UserName NVARCHAR(256) = NULL;

-- Optional database filter
DECLARE @DatabaseName NVARCHAR(128) = NULL;

SELECT
    AuditID,
    EventTime,
    UserName,
    UserRole,
    PCName,
    IPAddress,
    DatabaseName,
    SchemaName,
    TableName,
    Activity,
    Status,
    SQLStatement,
    ErrorMessage,
    ApplicationName

FROM dbo.UserActivityLog

WHERE EventTime >= @StartDate
  AND EventTime < DATEADD(DAY, 1, @EndDate)

  AND (
      @UserName IS NULL
      OR UserName = @UserName
  )

  AND (
      @DatabaseName IS NULL
      OR DatabaseName = @DatabaseName
  )

ORDER BY EventTime DESC;
GO

-- User-wise activity summary for selected period
DECLARE @SummaryStartDate DATE = '2026-11-01';
DECLARE @SummaryEndDate DATE = CAST(GETDATE() AS DATE);

SELECT
    UserName,
    UserRole,
    COUNT_BIG(*) AS TotalActivities,

    SUM(CASE WHEN Status = 'Success'
        THEN 1 ELSE 0 END) AS SuccessfulActivities,

    SUM(CASE WHEN Status = 'Failed'
        THEN 1 ELSE 0 END) AS FailedActivities,

    COUNT(DISTINCT DatabaseName) AS AccessedDatabases,

    MIN(EventTime) AS FirstActivity,
    MAX(EventTime) AS LastActivity

FROM dbo.UserActivityLog

WHERE EventTime >= @SummaryStartDate
  AND EventTime < DATEADD(DAY, 1, @SummaryEndDate)

GROUP BY
    UserName,
    UserRole

ORDER BY TotalActivities DESC;
GO