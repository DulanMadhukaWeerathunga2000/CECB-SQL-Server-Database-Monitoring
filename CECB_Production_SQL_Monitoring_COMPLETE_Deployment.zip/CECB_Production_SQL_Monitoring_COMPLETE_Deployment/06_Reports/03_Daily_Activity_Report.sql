USE CECB_Monitoring;
GO

/* =========================================================
   DAILY DATABASE ACTIVITY REPORT
   ========================================================= */

DECLARE @ReportDate DATE = CAST(GETDATE() AS DATE);

SELECT
    CAST(EventTime AS DATE) AS ActivityDate,
    UserName,
    UserRole,
    PCName,
    IPAddress,
    DatabaseName,
    Activity,

    COUNT_BIG(*) AS TotalActivities,

    SUM(CASE
        WHEN Status = 'Success' THEN 1
        ELSE 0
    END) AS SuccessfulActivities,

    SUM(CASE
        WHEN Status = 'Failed' THEN 1
        ELSE 0
    END) AS FailedActivities,

    MAX(EventTime) AS LastActivityTime

FROM dbo.UserActivityLog

WHERE EventTime >= @ReportDate
  AND EventTime < DATEADD(DAY, 1, @ReportDate)

GROUP BY
    CAST(EventTime AS DATE),
    UserName,
    UserRole,
    PCName,
    IPAddress,
    DatabaseName,
    Activity

ORDER BY
    UserName,
    DatabaseName,
    Activity;
GO

-- Daily total summary
DECLARE @SummaryDate DATE = CAST(GETDATE() AS DATE);

SELECT
    @SummaryDate AS ReportDate,
    COUNT_BIG(*) AS TotalActivities,

    SUM(CASE WHEN Status = 'Success'
        THEN 1 ELSE 0 END) AS SuccessfulActivities,

    SUM(CASE WHEN Status = 'Failed'
        THEN 1 ELSE 0 END) AS FailedActivities,

    COUNT(DISTINCT UserName) AS ActiveUsers,

    COUNT(DISTINCT DatabaseName) AS AccessedDatabases

FROM dbo.UserActivityLog

WHERE EventTime >= @SummaryDate
  AND EventTime < DATEADD(DAY, 1, @SummaryDate);
GO