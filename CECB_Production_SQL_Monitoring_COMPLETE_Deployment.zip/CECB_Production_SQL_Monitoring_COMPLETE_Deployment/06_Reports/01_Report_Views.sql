USE CECB_Monitoring;
GO

/* =========================================================
   CECB SQL SERVER DATABASE MONITORING SYSTEM
   REPORT VIEWS
   ========================================================= */

-- 1. Dashboard Summary
CREATE OR ALTER VIEW dbo.vw_DashboardSummary
AS
SELECT
    (SELECT COUNT_BIG(*)
     FROM dbo.UserActivityLog) AS TotalActivities,

    (SELECT COUNT_BIG(*)
     FROM dbo.UserErrorLog) AS TotalErrors,

    (SELECT COUNT_BIG(*)
     FROM dbo.DatabaseRestoreHistory) AS TotalRestores,

    (SELECT COUNT(DISTINCT UserName)
     FROM dbo.UserActivityLog
     WHERE UserName IS NOT NULL) AS TotalUsers;
GO

-- 2. User Summary
CREATE OR ALTER VIEW dbo.vw_DashboardUserSummary
AS
SELECT
    UserName,
    UserRole,
    COUNT_BIG(*) AS TotalActivities,
    SUM(CASE WHEN Status = 'Success' THEN 1 ELSE 0 END)
        AS SuccessfulActivities,
    SUM(CASE WHEN Status = 'Failed' THEN 1 ELSE 0 END)
        AS FailedActivities,
    MAX(EventTime) AS LastActivity
FROM dbo.UserActivityLog
GROUP BY UserName, UserRole;
GO

-- 3. Date Summary
CREATE OR ALTER VIEW dbo.vw_DashboardDateSummary
AS
SELECT
    CAST(EventTime AS DATE) AS ActivityDate,
    COUNT_BIG(*) AS TotalActivities,
    SUM(CASE WHEN Status = 'Success' THEN 1 ELSE 0 END)
        AS SuccessfulActivities,
    SUM(CASE WHEN Status = 'Failed' THEN 1 ELSE 0 END)
        AS FailedActivities
FROM dbo.UserActivityLog
GROUP BY CAST(EventTime AS DATE);
GO

-- 4. Error Summary
CREATE OR ALTER VIEW dbo.vw_DashboardErrorSummary
AS
SELECT
    CAST(EventTime AS DATE) AS ErrorDate,
    COUNT_BIG(*) AS TotalErrors,
    COUNT(DISTINCT UserName) AS AffectedUsers,
    COUNT(DISTINCT DatabaseName) AS AffectedDatabases
FROM dbo.UserErrorLog
GROUP BY CAST(EventTime AS DATE);
GO

-- 5. Recent Activity
CREATE OR ALTER VIEW dbo.vw_DashboardRecentActivity
AS
SELECT TOP (100)
    EventTime,
    UserName,
    UserRole,
    PCName,
    IPAddress,
    DatabaseName,
    Activity,
    Status,
    SQLStatement
FROM dbo.UserActivityLog
ORDER BY EventTime DESC;
GO

-- 6. Combined Monitoring Report
CREATE OR ALTER VIEW dbo.vw_CombinedMonitoringReport
AS
SELECT
    EventTime,
    UserName,
    UserRole,
    PCName,
    IPAddress,
    DatabaseName,
    Activity AS EventType,
    Status AS Result,
    SQLStatement AS Description,
    'ACTIVITY' AS RecordType
FROM dbo.UserActivityLog

UNION ALL

SELECT
    EventTime,
    UserName,
    CAST(NULL AS NVARCHAR(100)) AS UserRole,
    PCName,
    CAST(NULL AS NVARCHAR(50)) AS IPAddress,
    DatabaseName,
    CAST('ERROR' AS NVARCHAR(100)) AS EventType,
    CAST('Failed' AS NVARCHAR(50)) AS Result,
    ErrorMessage AS Description,
    'ERROR' AS RecordType
FROM dbo.UserErrorLog;
GO

-- 7. Error Details Report
CREATE OR ALTER VIEW dbo.vw_ErrorDetailsReport
AS
SELECT
    ErrorLogID,
    EventTime,
    ErrorNumber,
    Severity,
    ErrorState,
    UserName,
    PCName,
    DatabaseName,
    ApplicationName,
    SQLStatement,
    ErrorMessage
FROM dbo.UserErrorLog;
GO

-- 8. User Activity Report
CREATE OR ALTER VIEW dbo.vw_UserActivityReport
AS
SELECT
    AuditID,
    EventTime,
    UserName,
    UserRole,
    PCName,
    IPAddress,
    DatabaseName,
    SchemaName,
    TableName,
    Activity,
    Status,
    SQLStatement,
    ApplicationName
FROM dbo.UserActivityLog;
GO

-- 9. Database Activity Report
CREATE OR ALTER VIEW dbo.vw_DatabaseActivityReport
AS
SELECT
    DatabaseName,
    Activity,
    COUNT_BIG(*) AS TotalActivities,
    COUNT(DISTINCT UserName) AS TotalUsers,
    MAX(EventTime) AS LastActivity
FROM dbo.UserActivityLog
GROUP BY DatabaseName, Activity;
GO

-- 10. Monthly Activity Report
CREATE OR ALTER VIEW dbo.vw_MonthlyActivityReport
AS
SELECT
    YEAR(EventTime) AS ActivityYear,
    MONTH(EventTime) AS ActivityMonth,
    COUNT_BIG(*) AS TotalActivities,
    SUM(CASE WHEN Status = 'Success' THEN 1 ELSE 0 END)
        AS SuccessfulActivities,
    SUM(CASE WHEN Status = 'Failed' THEN 1 ELSE 0 END)
        AS FailedActivities,
    COUNT(DISTINCT UserName) AS TotalUsers
FROM dbo.UserActivityLog
GROUP BY YEAR(EventTime), MONTH(EventTime);
GO

PRINT 'All reporting views created successfully.';
GO