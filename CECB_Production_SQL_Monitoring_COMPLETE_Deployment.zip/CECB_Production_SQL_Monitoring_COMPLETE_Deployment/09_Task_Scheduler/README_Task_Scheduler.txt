# CECB SQL SERVER DATABASE MONITORING SYSTEM
## 09 – TASK SCHEDULER FOLDER README

### 1. PURPOSE

This folder contains PowerShell scripts used to register Windows Task Scheduler tasks for automated SQL Server monitoring and backup operations.

SQL Server Express does not include SQL Server Agent scheduling functionality.

Therefore, Windows Task Scheduler is used to execute the required batch files automatically.

Main functions:

- Automatic SQL activity collection.
- Monthly Full Backup scheduling.
- Weekly Differential Backup scheduling.
- Automated execution of monitoring and backup scripts.

---

### 2. FILE STRUCTURE

09_Task_Scheduler
│
├── README_Task_Scheduler.txt
├── 01_Register_Collection_Task.ps1
└── 02_Register_Backup_Tasks.ps1

---

### 3. FILE DESCRIPTIONS

#### 01_Register_Collection_Task.ps1

Purpose:

Registers the automatic SQL Server monitoring collection task.

Task name:

CECB Automatic Activity Collection

Execution frequency:

Every 5 minutes.

Script executed:

05_Collectors\07_Collect_All.bat

Functions:

- Registers the collection task.
- Configures the Windows account.
- Configures the execution interval.
- Configures task execution settings.

The collection batch file executes:

- SQL Audit collection.
- SQL Error collection.
- Database Restore History collection.

#### 02_Register_Backup_Tasks.ps1

Purpose:

Registers two automated database backup tasks.

Task 1:

CECB Automatic Monthly Full Backup

Schedule:

First day of every month at 1:00 AM.

Script:

08_Automation\01_Run_Monthly_Full_Backup.bat

Task 2:

CECB Automatic Weekly Differential Backup

Schedule:

Every Sunday at 2:00 AM.

Script:

08_Automation\02_Run_Weekly_Differential_Backup.bat

Functions:

- Registers the Monthly Full Backup task.
- Registers the Weekly Differential Backup task.
- Configures the Windows account.
- Configures task execution settings.

---

### 4. TASK SCHEDULE SUMMARY

Activity Collection:

Frequency: Every 5 minutes.

Monthly Full Backup:

Frequency: Monthly.
Day: First day of the month.
Time: 1:00 AM.

Weekly Differential Backup:

Frequency: Weekly.
Day: Sunday.
Time: 2:00 AM.

All schedules are proposed production schedules and must be approved before activation.

---

### 5. DEPLOYMENT REQUIREMENTS

Required components:

- Windows Task Scheduler.
- Windows PowerShell.
- SQL Server command-line utilities (sqlcmd).
- Approved SQL Server instance.
- Approved Windows account.
- Complete deployment folder structure.

Before registration:

1. Confirm the production deployment folder.
2. Confirm all referenced scripts exist.
3. Configure the production SQL Server instance.
4. Configure the approved Windows account.
5. Confirm SQL Server permissions.
6. Confirm backup folder permissions.
7. Confirm OneDrive folder access.
8. Obtain PM/DBA approval.

---

### 6. WINDOWS ACCOUNT REQUIREMENTS

The scripts use Interactive logon.

The approved Windows account must have:

- Permission to execute the required scripts.
- Permission to connect to SQL Server.
- Required database permissions for monitoring and backup.
- Access to the backup directory.
- Access to the OneDrive synchronization directory.

IMPORTANT:

Interactive tasks normally require the configured user to be logged on.

The OneDrive desktop client must be running and signed in for cloud synchronization.

If unattended operation is required while no user is logged on, the task logon configuration and OneDrive synchronization design must be reviewed separately.

Do not store account passwords directly in these scripts.

---

### 7. REGISTRATION PROCEDURE

After production approval:

Step 1:

Open PowerShell with the required administrative permissions.

Step 2:

Review the account and deployment path in:

01_Register_Collection_Task.ps1

Step 3:

Register the activity collection task.

Step 4:

Review the account and deployment path in:

02_Register_Backup_Tasks.ps1

Step 5:

Register the backup tasks.

Step 6:

Open Windows Task Scheduler.

Step 7:

Check the registered task names and schedules.

Step 8:

Verify task status and execution history.

Do not manually start production tasks until the DBA approves the execution test.

---

### 8. TASK VERIFICATION

Open:

Windows Task Scheduler

Check the following tasks:

1. CECB Automatic Activity Collection
2. CECB Automatic Monthly Full Backup
3. CECB Automatic Weekly Differential Backup

Verify:

- Task name.
- Trigger schedule.
- Configured Windows account.
- Task status.
- Last Run Time.
- Last Run Result.
- Next Run Time.

A registered task does not mean that the backup or collection operation has already succeeded.

Check the corresponding execution logs and SQL Server backup history.

---

### 9. TROUBLESHOOTING

Task registration failed:

Check PowerShell administrative permissions and account configuration.

Batch file not found:

Check the deployment directory and file names.

Task does not execute:

Check the configured Windows account and Task Scheduler history.

SQL Server connection failed:

Check the SQL Server instance name and account permissions.

OneDrive synchronization failed:

Check OneDrive sign-in status and destination folder access.

Task is missed while the computer is off:

Check the StartWhenAvailable setting and task history after the computer starts.

Task is already running:

The IgnoreNew setting prevents another instance from starting while the previous instance is running.

---

### 10. SECURITY AND OPERATIONAL NOTES

- Obtain PM/DBA approval before production registration.
- Do not register tasks on the local test PC.
- Do not store passwords in scripts.
- Use approved Windows authentication.
- Restrict task modification permissions.
- Review task execution history.
- Review backup logs regularly.
- Confirm OneDrive synchronization separately.
- Do not remove existing production backup tasks before validation.
- Do not disable the existing production backup system until the new system is approved and verified.

---

### 11. EXPECTED RESULT

The Task Scheduler component should provide:

- Automatic SQL Server activity collection every 5 minutes.
- Monthly Full Backup scheduling.
- Weekly Differential Backup scheduling.
- Automatic execution of approved scripts.
- Centralized task execution management.
- Scheduled backup and monitoring operations.

Project:

SQL Server Database Activity Monitoring, Backup and Restore Management System

Organization:

Central Engineering Consultancy Bureau (CECB)

Document:

Task Scheduler – Technical README

Deployment Status:

Proposed – Pending Production Approval