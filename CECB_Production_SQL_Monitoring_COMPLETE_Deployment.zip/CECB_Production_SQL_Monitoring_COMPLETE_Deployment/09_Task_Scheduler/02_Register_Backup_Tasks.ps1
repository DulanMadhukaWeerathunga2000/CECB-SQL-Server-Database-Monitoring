# =========================================================
# CECB SQL SERVER DATABASE MONITORING SYSTEM
# AUTOMATIC BACKUP TASK REGISTRATION
# =========================================================

$ErrorActionPreference = "Stop"

# Deployment configuration
$BaseDir = "C:\CECB_Production_SQL_Monitoring_COMPLETE_Deployment"
$AutomationDir = Join-Path $BaseDir "08_Automation"

# Replace with the approved Windows account
$TaskUser = "REPLACE_WITH_DOMAIN\SERVICE_ACCOUNT"

# Task names
$MonthlyTaskName = "CECB Automatic Monthly Full Backup"
$WeeklyTaskName = "CECB Automatic Weekly Differential Backup"

# Batch files
$MonthlyBatch = Join-Path $AutomationDir "01_Run_Monthly_Full_Backup.bat"
$WeeklyBatch = Join-Path $AutomationDir "02_Run_Weekly_Differential_Backup.bat"

Write-Host "CECB Backup Task Registration" -ForegroundColor Cyan

# Validate account configuration
if ($TaskUser -match "REPLACE_WITH") {
    throw "Configure the approved Windows account before running this script."
}

# Validate batch files
if (!(Test-Path -LiteralPath $MonthlyBatch)) {
    throw "Monthly backup batch file not found: $MonthlyBatch"
}

if (!(Test-Path -LiteralPath $WeeklyBatch)) {
    throw "Weekly backup batch file not found: $WeeklyBatch"
}

# Shared task principal
$Principal = New-ScheduledTaskPrincipal `
    -UserId $TaskUser `
    -LogonType Interactive `
    -RunLevel Highest

# Shared task settings
$Settings = New-ScheduledTaskSettingsSet `
    -StartWhenAvailable `
    -MultipleInstances IgnoreNew `
    -ExecutionTimeLimit (New-TimeSpan -Hours 6)

# ---------------------------------------------------------
# MONTHLY FULL BACKUP
# ---------------------------------------------------------

$MonthlyAction = New-ScheduledTaskAction `
    -Execute "$env:ComSpec" `
    -Argument "/c `"`"$MonthlyBatch`"`"" `
    -WorkingDirectory $BaseDir

$MonthlyTrigger = New-ScheduledTaskTrigger `
    -Monthly `
    -DaysOfMonth 1 `
    -At "1:00AM"

Register-ScheduledTask `
    -TaskName $MonthlyTaskName `
    -Action $MonthlyAction `
    -Trigger $MonthlyTrigger `
    -Principal $Principal `
    -Settings $Settings `
    -Description "Runs the CECB monthly SQL Server Full Backup and OneDrive copy process." `
    -Force | Out-Null

Write-Host "Monthly Full Backup task registered." -ForegroundColor Green

# ---------------------------------------------------------
# WEEKLY DIFFERENTIAL BACKUP
# ---------------------------------------------------------

$WeeklyAction = New-ScheduledTaskAction `
    -Execute "$env:ComSpec" `
    -Argument "/c `"`"$WeeklyBatch`"`"" `
    -WorkingDirectory $BaseDir

$WeeklyTrigger = New-ScheduledTaskTrigger `
    -Weekly `
    -DaysOfWeek Sunday `
    -At "2:00AM"

Register-ScheduledTask `
    -TaskName $WeeklyTaskName `
    -Action $WeeklyAction `
    -Trigger $WeeklyTrigger `
    -Principal $Principal `
    -Settings $Settings `
    -Description "Runs the CECB weekly SQL Server Differential Backup and OneDrive copy process." `
    -Force | Out-Null

Write-Host "Weekly Differential Backup task registered." -ForegroundColor Green

Write-Host ""
Write-Host "Backup tasks registered successfully." -ForegroundColor Green
Write-Host "Account: $TaskUser"
Write-Host "Monthly: First day of every month at 1:00 AM"
Write-Host "Weekly: Every Sunday at 2:00 AM"
Write-Host "Status: Registered (not manually started)"