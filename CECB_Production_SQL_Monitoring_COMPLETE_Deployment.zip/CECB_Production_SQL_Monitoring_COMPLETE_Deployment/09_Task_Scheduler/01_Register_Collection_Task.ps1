# =========================================================
# CECB SQL SERVER DATABASE MONITORING SYSTEM
# AUTOMATIC ACTIVITY COLLECTION TASK
# =========================================================

$ErrorActionPreference = "Stop"

# Deployment configuration
$BaseDir = "C:\CECB_Production_SQL_Monitoring_COMPLETE_Deployment"
$BatchFile = Join-Path $BaseDir "05_Collectors\07_Collect_All.bat"

# Replace with the approved Windows account
$TaskUser = "REPLACE_WITH_DOMAIN\SERVICE_ACCOUNT"

$TaskName = "CECB Automatic Activity Collection"

Write-Host "CECB Activity Collection Task Registration" -ForegroundColor Cyan

# Validate configuration
if ($TaskUser -match "REPLACE_WITH") {
    throw "Configure the approved Windows account before running this script."
}

if (!(Test-Path -LiteralPath $BatchFile)) {
    throw "Collection batch file not found: $BatchFile"
}

# Create scheduled task action
$Action = New-ScheduledTaskAction `
    -Execute "$env:ComSpec" `
    -Argument "/c `"`"$BatchFile`"`"" `
    -WorkingDirectory $BaseDir

# Run once initially, then repeat every 5 minutes
$StartTime = (Get-Date).AddMinutes(1)

$Trigger = New-ScheduledTaskTrigger `
    -Once `
    -At $StartTime `
    -RepetitionInterval (New-TimeSpan -Minutes 5) `
    -RepetitionDuration (New-TimeSpan -Days 3650)

# Use an interactive account
$Principal = New-ScheduledTaskPrincipal `
    -UserId $TaskUser `
    -LogonType Interactive `
    -RunLevel Highest

# Task settings
$Settings = New-ScheduledTaskSettingsSet `
    -StartWhenAvailable `
    -MultipleInstances IgnoreNew `
    -ExecutionTimeLimit (New-TimeSpan -Minutes 10)

# Register task
Register-ScheduledTask `
    -TaskName $TaskName `
    -Action $Action `
    -Trigger $Trigger `
    -Principal $Principal `
    -Settings $Settings `
    -Description "Collects SQL Server activity, error and restore history every five minutes." `
    -Force | Out-Null

Write-Host ""
Write-Host "Task registered successfully." -ForegroundColor Green
Write-Host "Task Name: $TaskName"
Write-Host "Account: $TaskUser"
Write-Host "Frequency: Every 5 minutes"
Write-Host "Status: Registered (not manually started)"