======================================================================
CENTRAL ENGINEERING CONSULTANCY BUREAU (CECB)
SQL SERVER DATABASE ACTIVITY MONITORING,
BACKUP AND RESTORE MANAGEMENT SYSTEM
======================================================================

TECHNICAL DEPLOYMENT PACKAGE
Version       : 1.0
Environment   : Proposed Production Deployment
Platform      : Microsoft SQL Server
Status        : PENDING PM / DBA APPROVAL

IMPORTANT NOTICE
----------------------------------------------------------------------
This package is prepared for technical review and proposed production
deployment.

The system has been developed and tested using a local test environment.
It has NOT been deployed to the original CECB production SQL Server.

Do not execute production scripts until approval is obtained from the
Project Manager, Database Administrator and relevant IT authorities.

Do not modify, delete or overwrite existing production databases,
backup files, SQL Server Audit configurations or scheduled tasks without
formal approval.


1. PROJECT PURPOSE
======================================================================

The purpose of this system is to provide a centralized SQL Server
Database Activity Monitoring, Backup and Restore Management System.

The system is designed to:

1. Monitor SQL Server user login and logout activities.
2. Record database activity performed by users.
3. Identify user roles and associated computers.
4. Capture SQL Server errors.
5. Maintain database restore history.
6. Generate daily, user-wise and monthly activity reports.
7. Perform monthly Full database backups.
8. Perform weekly Differential database backups.
9. Synchronize backup files to the approved OneDrive location.
10. Provide verification and restore procedures.

The system aims to improve database security, accountability,
backup management and recovery readiness.


2. PACKAGE DIRECTORY STRUCTURE
======================================================================

CECB_Production_SQL_Monitoring_COMPLETE_Deployment
|
|-- README_Deployment.txt
|
|-- 01_Prerequisites
|   |-- README_Prerequisites.txt
|   |-- 00_Production_Precheck.sql
|
|-- 02_Monitoring_Database
|   |-- README_Monitoring_Database.txt
|   |-- 00_Create_Database.sql
|   |-- 01_Create_Tables.sql
|   |-- 02_Seed_Role_Map.sql
|   |-- 03_Create_RestoreHistory_Table.sql
|   |-- 04_Create_UserErrorLog_Table.sql
|   |-- 05_Create_UserRoleMap.sql
|
|-- 03_SQL_Audit
|   |-- README_SQL_Audit.txt
|   |-- 01_Create_Server_Audits.sql
|   |-- 02_Server_Audit_Specifications.sql
|   |-- 03_CECB_System_Database_Audit.sql
|   |-- 04_Enable_Server_Audits.sql
|
|-- 04_Extended_Events
|   |-- README_Extended_Events.txt
|   |-- 01_Create_Error_Monitor.sql
|
|-- 05_Collectors
|   |-- README_Collectors.txt
|   |-- 01_usp_CollectUserActivity.sql
|   |-- 02_usp_CollectUserErrors.sql
|   |-- 03_usp_CollectRestoreHistory.sql
|   |-- 04_Collect_Audit.sql
|   |-- 05_Collect_Errors.sql
|   |-- 06_Collect_RestoreHistory.sql
|   |-- 07_Collect_All.bat
|
|-- 06_Reports
|   |-- README_Reports.txt
|   |-- 01_Report_Views.sql
|   |-- 02_Verify_Report_Views.sql
|   |-- 03_Daily_Activity_Report.sql
|   |-- 04_User_Activity_Details_Report.sql
|
|-- 07_Backup
|   |-- README_Backup.txt
|   |-- 01_Monthly_Full_Backup.sql
|   |-- 02_Weekly_Differential_Backup.sql
|   |-- 03_Verify_Backup_History.sql
|
|-- 08_Automation
|   |-- README_Automation.txt
|   |-- 01_Run_Monthly_Full_Backup.bat
|   |-- 02_Run_Weekly_Differential_Backup.bat
|   |-- 03_Sync_To_OneDrive.ps1
|
|-- 09_Task_Scheduler
|   |-- README_Task_Scheduler.txt
|   |-- 01_Register_Collection_Task.ps1
|   |-- 02_Register_Backup_Tasks.ps1
|
|-- 10_Verification
|   |-- README_Verification.txt
|   |-- 01_Verify_System.sql
|
|-- 11_Documentation
    |-- README_Documentation.txt
    |-- 01_Deployment_Checklist.txt
    |-- 02_Restore_Procedure.txt


3. SYSTEM REQUIREMENTS
======================================================================

3.1 Software Requirements

- Microsoft Windows Server (supported version).
- Microsoft SQL Server (version compatible with the scripts).
- SQL Server Management Studio (SSMS).
- SQL Server command-line utility (sqlcmd).
- Windows PowerShell.
- OneDrive for Business.
- Windows Task Scheduler.

3.2 SQL Server Requirements

The deployment must be reviewed against the actual production
SQL Server edition, version and configuration.

SQL Server Express does not provide SQL Server Agent.
Windows Task Scheduler is therefore used for automation.

3.3 Windows Requirements

The production server must have:

- Sufficient disk space.
- Access to the approved backup location.
- Required permissions for SQL Server service account.
- Required permissions for the scheduled task account.
- Network connectivity to the approved OneDrive location.


4. PRODUCTION DATABASE SCOPE
======================================================================

The following databases are included in the proposed backup scope:

Database Name       Recovery Model
----------------------------------
CECB_ERP            FULL
CECB_Monitoring     SIMPLE
CECB_System         SIMPLE
LeaveDB             FULL
SP_USER_LOGIN       FULL

The actual production database names and recovery models must be
confirmed by the DBA before deployment.

IMPORTANT:

CECB_Monitoring is the proposed database for storing monitoring records.

The UserRoleMap table is used to identify users in monitoring reports.
It does not grant SQL Server database permissions.

Production SQL logins, Windows accounts and database roles must be
confirmed before preparing the production role mapping.


5. MONITORING CONFIGURATION
======================================================================

The monitoring system uses:

1. SQL Server Audit.
2. Extended Events.
3. SQL Server stored procedures.
4. Monitoring database tables.
5. Windows Task Scheduler.

The system is designed to collect:

- Successful login activities.
- Failed login activities.
- Logout activities.
- SELECT activities.
- INSERT activities.
- UPDATE activities.
- DELETE activities.
- CREATE activities.
- ALTER activities.
- DROP activities.
- EXECUTE activities.
- SQL Server error events.
- Database restore history.

IMPORTANT MONITORING SCOPE:

The current database-level audit script specifically targets
CECB_System.

Monitoring coverage for other production databases must be reviewed
and approved by the DBA before deployment.

Do not assume that every database is monitored for all DML and SELECT
operations until the required audit specifications are configured
and verified.


6. MONITORING DATA COLLECTION
======================================================================

The monitoring data is stored in the CECB_Monitoring database.

Main tables:

1. UserActivityLog
   Stores SQL Server user activity records.

2. UserErrorLog
   Stores SQL Server error information.

3. DatabaseRestoreHistory
   Stores database restore history.

4. UserRoleMap
   Stores user-to-role mapping information.

Collection interval:

EVERY 5 MINUTES

The Windows Task Scheduler executes:

05_Collectors\07_Collect_All.bat

The batch file executes the following collection scripts:

- 04_Collect_Audit.sql
- 05_Collect_Errors.sql
- 06_Collect_RestoreHistory.sql

The collection procedures use duplicate-prevention mechanisms
to reduce repeated records.


7. REPORTING SYSTEM
======================================================================

The 06_Reports folder contains SQL reporting scripts.

Available reports include:

- Dashboard Summary.
- User Activity Summary.
- Date-wise Activity Summary.
- Error Summary.
- Recent Activity.
- Combined Monitoring Report.
- Error Details Report.
- User Activity Report.
- Database Activity Report.
- Monthly Activity Report.
- Daily Activity Report.
- User Activity Details Report.

Reports are generated from information stored in the
CECB_Monitoring database.

The reports can be executed through SQL Server Management Studio
and exported using SSMS-supported formats.


8. DATABASE BACKUP STRATEGY
======================================================================

The proposed backup strategy is:

A. MONTHLY FULL BACKUP

Schedule:
First day of every month at 1:00 AM.

Backup type:
FULL DATABASE BACKUP.

B. WEEKLY DIFFERENTIAL BACKUP

Schedule:
Every Sunday at 2:00 AM.

Backup type:
DIFFERENTIAL DATABASE BACKUP.

Differential backups contain changes since the applicable Full backup.

C. TRANSACTION LOG BACKUPS

No transaction log backup schedule is included in this version.

For databases using FULL recovery model, the DBA must separately
review transaction log backup requirements.

Point-in-time recovery cannot be assumed without an appropriate
transaction log backup strategy.

D. BACKUP LOCATION

Proposed local backup folder:

C:\CECB_Monitoring\Backups

The folder must be created on the approved production server.

The SQL Server Database Engine service account must have the
necessary write permissions.

E. BACKUP VERIFICATION

The package includes a backup history verification script.

RESTORE VERIFYONLY WITH CHECKSUM can be used for an additional
backup readability check.

However, this does not replace an isolated test restore.

A separate test restore must be completed before accepting the
backup solution for production use.


9. ONEDRIVE BACKUP SYNCHRONIZATION
======================================================================

The 08_Automation folder contains:

01_Run_Monthly_Full_Backup.bat
02_Run_Weekly_Differential_Backup.bat
03_Sync_To_OneDrive.ps1

After a successful backup operation, the corresponding batch file
runs the OneDrive synchronization script.

Proposed OneDrive destination:

C:\Users\REPLACE_WITH_WINDOWS_USER\OneDrive - CENTRAL ENGINEERING
CONSULTANCY BUREAU\CECB_Database_Monitoring\Database_Backups

The actual Windows user profile and OneDrive folder must be confirmed
on the production server.

IMPORTANT:

The synchronization script copies files to the local OneDrive folder.

Actual cloud synchronization must be confirmed using OneDrive status.

The synchronization process must not delete existing backup files.

Do not configure automatic deletion of old production backups without
a separately approved retention policy.


10. WINDOWS TASK SCHEDULER
======================================================================

The package uses Windows Task Scheduler for automation.

Task 1:
Name:
CECB Automatic Activity Collection

Schedule:
Every 5 minutes.

Action:
05_Collectors\07_Collect_All.bat

Task 2:
Name:
CECB Automatic Monthly Full Backup

Schedule:
First day of every month at 1:00 AM.

Action:
08_Automation\01_Run_Monthly_Full_Backup.bat

Task 3:
Name:
CECB Automatic Weekly Differential Backup

Schedule:
Every Sunday at 2:00 AM.

Action:
08_Automation\02_Run_Weekly_Differential_Backup.bat

The PowerShell registration scripts are available in the
09_Task_Scheduler folder.

The scheduled task account must have appropriate SQL Server,
Windows folder and OneDrive permissions.

The current task registration scripts use an Interactive logon
configuration. This requires the account to be logged in.

The final unattended execution method must be approved by IT/DBA
before production registration.


11. DEPLOYMENT EXECUTION ORDER
======================================================================

The following order is recommended.

STEP 01:
Review 01_Prerequisites.

Execute:
00_Production_Precheck.sql

Purpose:
Check production SQL Server environment and prerequisites.

STEP 02:
Prepare monitoring database.

Folder:
02_Monitoring_Database

Execution order:

1. 00_Create_Database.sql
2. 01_Create_Tables.sql
3. 03_Create_RestoreHistory_Table.sql
4. 04_Create_UserErrorLog_Table.sql
5. 05_Create_UserRoleMap.sql
6. 02_Seed_Role_Map.sql

Purpose:
Create monitoring database, tables and approved role mapping.

STEP 03:
Prepare SQL Server Audit.

Folder:
03_SQL_Audit

Execution order:

1. 01_Create_Server_Audits.sql
2. 02_Server_Audit_Specifications.sql
3. 03_CECB_System_Database_Audit.sql
4. 04_Enable_Server_Audits.sql

Purpose:
Create and configure approved SQL Server Audit objects.

STEP 04:
Prepare Extended Events.

Execute:
04_Extended_Events\01_Create_Error_Monitor.sql

Purpose:
Create SQL Server error monitoring session.

STEP 05:
Prepare collection procedures.

Folder:
05_Collectors

Execution order:

1. 01_usp_CollectUserActivity.sql
2. 02_usp_CollectUserErrors.sql
3. 03_usp_CollectRestoreHistory.sql

Then verify:

4. 04_Collect_Audit.sql
5. 05_Collect_Errors.sql
6. 06_Collect_RestoreHistory.sql

STEP 06:
Prepare reports.

Folder:
06_Reports

Execution order:

1. 01_Report_Views.sql
2. 02_Verify_Report_Views.sql

Then execute the required daily and user activity reports.

STEP 07:
Prepare backup scripts.

Folder:
07_Backup

Review:

1. 01_Monthly_Full_Backup.sql
2. 02_Weekly_Differential_Backup.sql
3. 03_Verify_Backup_History.sql

The first production Full backup must complete successfully before
the first Differential backup is executed.

STEP 08:
Prepare automation.

Folder:
08_Automation

Configure:

1. Monthly Full backup batch file.
2. Weekly Differential backup batch file.
3. OneDrive synchronization PowerShell script.

STEP 09:
Prepare Windows Task Scheduler.

Folder:
09_Task_Scheduler

Register tasks only after IT/DBA approval.

STEP 10:
Verify the complete system.

Folder:
10_Verification

Execute:
01_Verify_System.sql

STEP 11:
Review deployment documents.

Folder:
11_Documentation

Complete:

1. Deployment checklist.
2. Restore procedure.
3. PM/DBA acceptance and sign-off.


12. PRODUCTION CONFIGURATION PLACEHOLDERS
======================================================================

Before deployment, replace and verify the following placeholders:

REPLACE_WITH_PRODUCTION_SQL_INSTANCE
REPLACE_WITH_WINDOWS_USER
REPLACE_WITH_DOMAIN\SERVICE_ACCOUNT

Also verify:

- SQL Server instance name.
- SQL Server service account.
- Windows scheduled task account.
- Production backup directory.
- OneDrive destination directory.
- SQL login and role mapping.
- SQL Server Audit file permissions.
- Extended Events file permissions.

Never use local test computer values as production configuration
without confirmation.


13. SECURITY AND PERMISSIONS
======================================================================

The deployment must follow the principle of least privilege.

Required permission categories:

SQL Server:
- Create and configure approved SQL Server Audit objects.
- Create monitoring database objects.
- Read SQL Server Audit files.
- Read Extended Events files.
- Read required msdb backup and restore history.
- Execute approved collection procedures.
- Execute approved backup operations.

Windows:
- Read and execute deployment scripts.
- Write audit and backup files where required.
- Write application logs.
- Access the approved OneDrive synchronization folder.

The SQL Server Database Engine service account and scheduled task
account are separate identities and must be configured independently.

Do not grant sysadmin or administrator privileges unnecessarily.


14. RESTORE AND DISASTER RECOVERY
======================================================================

The package includes:

11_Documentation\02_Restore_Procedure.txt

The restore process must be performed only by authorized DBA staff.

General restore sequence:

1. Identify the correct Full backup.
2. Identify the matching Differential backup.
3. Verify backup files.
4. Review RESTORE FILELISTONLY output.
5. Prepare a separate test database.
6. Restore Full backup using NORECOVERY.
7. Restore Differential backup using RECOVERY.
8. Run DBCC CHECKDB.
9. Record the test restore result.

A separate MOVE clause must be prepared for every logical data,
log or other database file listed by RESTORE FILELISTONLY.

Never perform a test restore over an existing production database.


15. LOGGING AND TROUBLESHOOTING
======================================================================

The automation scripts maintain execution logs in their configured
Logs directories.

If collection fails, check:

- SQL Server connectivity.
- sqlcmd availability.
- SQL Server permissions.
- Audit file path and permissions.
- Extended Events file path and permissions.
- Scheduled task execution history.
- Batch file configuration.

If backup fails, check:

- Database status.
- Backup folder availability.
- Disk space.
- SQL Server service account permissions.
- Backup history.
- Differential base compatibility.

If OneDrive synchronization fails, check:

- OneDrive application status.
- Windows user login.
- OneDrive destination folder.
- File access permissions.
- Synchronization status.


16. PRODUCTION DEPLOYMENT SAFETY
======================================================================

The following rules are mandatory:

1. Obtain PM and DBA approval before deployment.
2. Confirm the production database inventory.
3. Take and verify existing production backups.
4. Do not delete existing production backup files.
5. Do not disable existing backup jobs without approval.
6. Do not overwrite existing audit configurations.
7. Do not change production database recovery models without approval.
8. Do not create scheduled tasks before approval.
9. Test all scripts in a suitable non-production environment.
10. Perform a separate restore test.
11. Document all deployment changes.
12. Obtain final acceptance from the responsible authorities.

The original production environment must remain unchanged until
formal approval is received.


17. ACCEPTANCE CRITERIA
======================================================================

The proposed system can be considered ready for production acceptance
only after the following items are verified:

[ ] Production prerequisites confirmed.
[ ] Monitoring database created successfully.
[ ] Required monitoring tables created.
[ ] Production user role mapping verified.
[ ] SQL Server Audit configured and verified.
[ ] Required database audit coverage verified.
[ ] Extended Events error monitoring verified.
[ ] Collection procedures executed successfully.
[ ] Five-minute collection schedule verified.
[ ] Monitoring reports generated successfully.
[ ] Monthly Full backup completed successfully.
[ ] Weekly Differential backup completed successfully.
[ ] Backup files verified.
[ ] OneDrive synchronization confirmed.
[ ] Isolated test restore completed successfully.
[ ] Scheduled tasks verified.
[ ] PM/DBA approval obtained.
[ ] Final deployment acceptance recorded.


18. FINAL STATUS
======================================================================

Project:
SQL Server Database Activity Monitoring,
Backup and Restore Management System.

Package:
CECB_Production_SQL_Monitoring_COMPLETE_Deployment

Current status:
TECHNICAL PROPOSAL / PRE-PRODUCTION DEPLOYMENT PACKAGE.

Production deployment:
PENDING APPROVAL.

The package is intended to support technical review, controlled
deployment planning, monitoring configuration, backup automation,
restore verification and future production implementation.

No production deployment is confirmed by this document.


======================================================================
END OF README_Deployment.txt
======================================================================