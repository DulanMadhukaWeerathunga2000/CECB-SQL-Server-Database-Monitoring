/*
============================================================
CECB SQL SERVER DATABASE MONITORING SYSTEM
SYSTEM VERIFICATION SCRIPT
============================================================

File:
01_Verify_System.sql

Purpose:
Verify the installation and configuration of the
CECB SQL Server Database Monitoring and Backup System.

IMPORTANT:
- READ-ONLY verification script.
- Does not create or modify database objects.
- Does not enable or disable SQL Server Audits.
- Does not start or stop Extended Events.
- Does not perform backup or restore operations.

Production execution requires DBA approval.

============================================================
*/

SET NOCOUNT ON;

PRINT '================================================';
PRINT 'CECB SYSTEM VERIFICATION STARTED';
PRINT '================================================';

------------------------------------------------------------
-- 1. SQL SERVER INFORMATION
------------------------------------------------------------

PRINT '';
PRINT '1. SQL SERVER INFORMATION';

SELECT
    @@SERVERNAME AS SQLServerName,
    SERVERPROPERTY('ProductVersion') AS SQLServerVersion,
    SERVERPROPERTY('Edition') AS SQLEdition,
    SERVERPROPERTY('ProductLevel') AS ProductLevel,
    GETDATE() AS VerificationDateTime;

------------------------------------------------------------
-- 2. DATABASE STATUS
------------------------------------------------------------

PRINT '';
PRINT '2. DATABASE STATUS';

SELECT
    name AS DatabaseName,
    state_desc AS DatabaseStatus,
    recovery_model_desc AS RecoveryModel,
    compatibility_level AS CompatibilityLevel
FROM sys.databases
WHERE name IN
(
    'CECB_Monitoring',
    'CECB_System',
    'CECB_ERP',
    'LeaveDB',
    'SP_USER_LOGIN'
)
ORDER BY name;

------------------------------------------------------------
-- 3. MONITORING DATABASE TABLES
------------------------------------------------------------

PRINT '';
PRINT '3. MONITORING DATABASE TABLES';

IF DB_ID('CECB_Monitoring') IS NOT NULL
BEGIN
    SELECT
        E.ObjectName,
        CASE
            WHEN T.object_id IS NOT NULL THEN 'EXISTS'
            ELSE 'MISSING'
        END AS VerificationStatus
    FROM
    (
        VALUES
            ('UserActivityLog'),
            ('UserErrorLog'),
            ('DatabaseRestoreHistory'),
            ('UserRoleMap')
    ) AS E(ObjectName)
    LEFT JOIN CECB_Monitoring.sys.tables AS T
        ON T.name = E.ObjectName
       AND T.schema_id = 1
    ORDER BY E.ObjectName;
END
ELSE
BEGIN
    PRINT 'ERROR: CECB_Monitoring database does not exist.';
END;

------------------------------------------------------------
-- 4. MONITORING DATA COUNTS
------------------------------------------------------------

PRINT '';
PRINT '4. MONITORING DATA COUNTS';

IF DB_ID('CECB_Monitoring') IS NOT NULL
BEGIN
    EXEC CECB_Monitoring.sys.sp_executesql N'
        SELECT
            ''UserActivityLog'' AS TableName,
            COUNT_BIG(*) AS TotalRecords
        FROM dbo.UserActivityLog

        UNION ALL

        SELECT
            ''UserErrorLog'',
            COUNT_BIG(*)
        FROM dbo.UserErrorLog

        UNION ALL

        SELECT
            ''DatabaseRestoreHistory'',
            COUNT_BIG(*)
        FROM dbo.DatabaseRestoreHistory

        UNION ALL

        SELECT
            ''UserRoleMap'',
            COUNT_BIG(*)
        FROM dbo.UserRoleMap;
    ';
END;

------------------------------------------------------------
-- 5. COLLECTOR STORED PROCEDURES
------------------------------------------------------------

PRINT '';
PRINT '5. COLLECTOR STORED PROCEDURES';

IF DB_ID('CECB_Monitoring') IS NOT NULL
BEGIN
    SELECT
        E.ObjectName,
        CASE
            WHEN P.object_id IS NOT NULL THEN 'EXISTS'
            ELSE 'MISSING'
        END AS VerificationStatus
    FROM
    (
        VALUES
            ('usp_CollectUserActivity'),
            ('usp_CollectUserErrors'),
            ('usp_CollectRestoreHistory')
    ) AS E(ObjectName)
    LEFT JOIN CECB_Monitoring.sys.procedures AS P
        ON P.name = E.ObjectName
       AND P.schema_id = 1
    ORDER BY E.ObjectName;
END;

------------------------------------------------------------
-- 6. REPORT VIEWS
------------------------------------------------------------

PRINT '';
PRINT '6. REPORT VIEWS';

IF DB_ID('CECB_Monitoring') IS NOT NULL
BEGIN
    SELECT
        E.ObjectName,
        CASE
            WHEN V.object_id IS NOT NULL THEN 'EXISTS'
            ELSE 'MISSING'
        END AS VerificationStatus
    FROM
    (
        VALUES
            ('vw_DashboardSummary'),
            ('vw_DashboardUserSummary'),
            ('vw_DashboardDateSummary'),
            ('vw_DashboardErrorSummary'),
            ('vw_DashboardRecentActivity'),
            ('vw_CombinedMonitoringReport'),
            ('vw_ErrorDetailsReport'),
            ('vw_UserActivityReport'),
            ('vw_DatabaseActivityReport'),
            ('vw_MonthlyActivityReport')
    ) AS E(ObjectName)
    LEFT JOIN CECB_Monitoring.sys.views AS V
        ON V.name = E.ObjectName
       AND V.schema_id = 1
    ORDER BY E.ObjectName;
END;

------------------------------------------------------------
-- 7. SQL SERVER AUDIT STATUS
------------------------------------------------------------

PRINT '';
PRINT '7. SQL SERVER AUDIT STATUS';

SELECT
    name AS AuditName,
    is_state_enabled AS IsEnabled,
    status_desc AS AuditStatus,
    queue_delay,
    on_failure_desc AS OnFailureAction
FROM sys.server_audits
WHERE name IN
(
    'CECB_Server_Audit',
    'Full_Server_Audit',
    'Role_Activity_Audit'
)
ORDER BY name;

------------------------------------------------------------
-- 8. SERVER AUDIT SPECIFICATION STATUS
------------------------------------------------------------

PRINT '';
PRINT '8. SERVER AUDIT SPECIFICATIONS';

SELECT
    name AS SpecificationName,
    is_state_enabled AS IsEnabled,
    create_date,
    modify_date
FROM sys.server_audit_specifications
WHERE name IN
(
    'CECB_Login_Audit',
    'Server_Wide_Tracking',
    'Role_Activity_Spec'
)
ORDER BY name;

------------------------------------------------------------
-- 9. CECB_SYSTEM DATABASE AUDIT SPECIFICATION
------------------------------------------------------------

PRINT '';
PRINT '9. CECB_SYSTEM DATABASE AUDIT SPECIFICATION';

IF DB_ID('CECB_System') IS NOT NULL
BEGIN
    EXEC CECB_System.sys.sp_executesql N'
        SELECT
            name AS SpecificationName,
            is_state_enabled AS IsEnabled,
            create_date,
            modify_date
        FROM sys.database_audit_specifications
        WHERE name = ''CECB_System_Database_Audit'';
    ';
END
ELSE
BEGIN
    PRINT 'CECB_System database does not exist.';
END;

------------------------------------------------------------
-- 10. EXTENDED EVENTS SESSION STATUS
------------------------------------------------------------

PRINT '';
PRINT '10. EXTENDED EVENTS SESSION STATUS';

SELECT
    S.name AS SessionName,
    CASE
        WHEN X.name IS NOT NULL THEN 'RUNNING'
        ELSE 'NOT RUNNING'
    END AS RuntimeStatus,
    S.startup_state AS StartWithSQLServer
FROM sys.server_event_sessions AS S
LEFT JOIN sys.dm_xe_sessions AS X
    ON X.name = S.name
WHERE S.name = 'CECB_Error_Monitor';

------------------------------------------------------------
-- 11. DATABASE BACKUP HISTORY
------------------------------------------------------------

PRINT '';
PRINT '11. DATABASE BACKUP HISTORY';

SELECT TOP (50)
    BS.database_name AS DatabaseName,
    CASE
        WHEN BS.type = 'D' THEN 'FULL'
        WHEN BS.type = 'I' THEN 'DIFFERENTIAL'
        WHEN BS.type = 'L' THEN 'LOG'
        ELSE BS.type
    END AS BackupType,
    BS.backup_start_date AS BackupStartDate,
    BS.backup_finish_date AS BackupFinishDate,
    CAST(BS.backup_size / 1048576.0 AS DECIMAL(18,2))
        AS BackupSizeMB,
    BMF.physical_device_name AS BackupLocation,
    BS.has_backup_checksums AS HasBackupChecksum
FROM msdb.dbo.backupset AS BS
LEFT JOIN msdb.dbo.backupmediafamily AS BMF
    ON BS.media_set_id = BMF.media_set_id
WHERE BS.database_name IN
(
    'CECB_ERP',
    'CECB_Monitoring',
    'CECB_System',
    'LeaveDB',
    'SP_USER_LOGIN'
)
ORDER BY BS.backup_finish_date DESC;

------------------------------------------------------------
-- 12. DATABASE RESTORE HISTORY
------------------------------------------------------------

PRINT '';
PRINT '12. DATABASE RESTORE HISTORY';

SELECT TOP (50)
    restore_history_id AS RestoreHistoryID,
    destination_database_name AS DatabaseName,
    restore_date AS RestoreDate,
    user_name AS RestoredBy,
    CASE
        WHEN restore_type = 'D' THEN 'DATABASE'
        WHEN restore_type = 'I' THEN 'DIFFERENTIAL'
        WHEN restore_type = 'L' THEN 'LOG'
        ELSE restore_type
    END AS RestoreType
FROM msdb.dbo.restorehistory
WHERE destination_database_name IN
(
    'CECB_ERP',
    'CECB_Monitoring',
    'CECB_System',
    'LeaveDB',
    'SP_USER_LOGIN'
)
ORDER BY restore_date DESC;

------------------------------------------------------------
-- 13. RECENT MONITORING ACTIVITY
------------------------------------------------------------

PRINT '';
PRINT '13. RECENT MONITORING ACTIVITY';

IF DB_ID('CECB_Monitoring') IS NOT NULL
BEGIN
    EXEC CECB_Monitoring.sys.sp_executesql N'
        SELECT TOP (20)
            EventTime,
            UserName,
            UserRole,
            PCName,
            IPAddress,
            DatabaseName,
            Activity,
            Status
        FROM dbo.UserActivityLog
        ORDER BY EventTime DESC;
    ';
END;

------------------------------------------------------------
-- 14. RECENT ERROR RECORDS
------------------------------------------------------------

PRINT '';
PRINT '14. RECENT ERROR RECORDS';

IF DB_ID('CECB_Monitoring') IS NOT NULL
BEGIN
    EXEC CECB_Monitoring.sys.sp_executesql N'
        SELECT TOP (20)
            EventTime,
            ErrorNumber,
            Severity,
            UserName,
            PCName,
            DatabaseName,
            ErrorMessage
        FROM dbo.UserErrorLog
        ORDER BY EventTime DESC;
    ';
END;

------------------------------------------------------------
-- 15. RECENT COLLECTED RESTORE RECORDS
------------------------------------------------------------

PRINT '';
PRINT '15. COLLECTED RESTORE RECORDS';

IF DB_ID('CECB_Monitoring') IS NOT NULL
BEGIN
    EXEC CECB_Monitoring.sys.sp_executesql N'
        SELECT TOP (20)
            RestoreDate,
            DatabaseName,
            BackupFile,
            RestoredBy,
            PCName,
            RestoreStatus,
            Remarks
        FROM dbo.DatabaseRestoreHistory
        ORDER BY RestoreDate DESC;
    ';
END;

------------------------------------------------------------
-- 16. FINAL VERIFICATION MESSAGE
------------------------------------------------------------

PRINT '';
PRINT '================================================';
PRINT 'CECB SYSTEM VERIFICATION COMPLETED';
PRINT '================================================';

PRINT 'Review all result sets for missing objects,';
PRINT 'disabled audits, inactive Extended Events,';
PRINT 'missing backup records and collection errors.';

PRINT 'Backup history does not guarantee successful restore.';
PRINT 'An isolated test restore is required.';

PRINT 'Verification completed at: '
    + CONVERT(VARCHAR(30), GETDATE(), 121);

GO