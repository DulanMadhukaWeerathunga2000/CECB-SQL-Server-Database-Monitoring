# CECB SQL SERVER DATABASE MONITORING SYSTEM
## 10 – VERIFICATION FOLDER README

### 1. PURPOSE

This folder contains SQL Server verification scripts used to
check the installation, configuration and operational status
of the CECB SQL Server Database Monitoring and Backup System.

The verification component helps administrators confirm
whether the required monitoring and backup components
are available after deployment.

Main verification areas:

- SQL Server information.
- Database availability.
- Monitoring database tables.
- Monitoring data records.
- Collector stored procedures.
- Reporting views.
- SQL Server Audit status.
- Server Audit Specifications.
- Database Audit Specification.
- Extended Events session status.
- Database backup history.
- Database restore history.
- Recent collected activity and errors.

IMPORTANT:

The verification script is read-only.

It does not create, modify or delete database objects.
It does not enable or disable SQL Server Audits.
It does not start or stop Extended Events.
It does not perform database backup or restore operations.

---

### 2. FILE STRUCTURE

10_Verification
|
|-- README_Verification.txt
|
|-- 01_Verify_System.sql

---

### 3. FILE DESCRIPTION

01_Verify_System.sql

Purpose:

Performs a general verification of the CECB SQL Server
Monitoring and Backup System.

Main functions:

- Displays SQL Server information.
- Checks required database availability.
- Checks monitoring database tables.
- Displays monitoring record counts.
- Checks collector stored procedures.
- Checks reporting views.
- Displays SQL Server Audit status.
- Checks Server Audit Specifications.
- Checks the CECB_System database audit specification.
- Checks the Extended Events session.
- Displays database backup history.
- Displays database restore history.
- Displays recent collected activity.
- Displays recent collected error records.
- Displays collected restore records.

Execution:

Run the script using SQL Server Management Studio
after the approved deployment scripts have been executed.

---

### 4. DATABASES CHECKED

The verification script checks:

1. CECB_Monitoring
2. CECB_System
3. CECB_ERP
4. LeaveDB
5. SP_USER_LOGIN

The script displays database status and recovery model.

---

### 5. MONITORING COMPONENTS CHECKED

Monitoring tables:

- UserActivityLog
- UserErrorLog
- DatabaseRestoreHistory
- UserRoleMap

Collector stored procedures:

- usp_CollectUserActivity
- usp_CollectUserErrors
- usp_CollectRestoreHistory

Reporting views:

- vw_DashboardSummary
- vw_DashboardUserSummary
- vw_DashboardDateSummary
- vw_DashboardErrorSummary
- vw_DashboardRecentActivity
- vw_CombinedMonitoringReport
- vw_ErrorDetailsReport
- vw_UserActivityReport
- vw_DatabaseActivityReport
- vw_MonthlyActivityReport

---

### 6. SQL SERVER AUDIT VERIFICATION

The script checks:

- CECB_Server_Audit
- Full_Server_Audit
- Role_Activity_Audit
- CECB_Login_Audit
- Server_Wide_Tracking
- Role_Activity_Spec
- CECB_System_Database_Audit

It displays whether the relevant audits and
audit specifications are enabled.

A disabled Audit is not automatically enabled by this script.
The DBA must investigate and approve any configuration change.

---

### 7. EXTENDED EVENTS VERIFICATION

The script checks the following Extended Events session:

CECB_Error_Monitor

The result indicates whether the session is currently running.

A configured session and a running session are different
states. Review the result before confirming operation.

---

### 8. BACKUP VERIFICATION

The script reads backup history from:

msdb.dbo.backupset
msdb.dbo.backupmediafamily

It displays:

- Database name.
- Backup type.
- Backup start date.
- Backup finish date.
- Backup size.
- Backup file location.
- Checksum information.

Expected backup strategy:

Monthly Full Backup:
First day of every month at 1:00 AM.

Weekly Differential Backup:
Every Sunday at 2:00 AM.

IMPORTANT:

Backup history alone does not prove that a backup file
is complete, readable or restorable.

Use RESTORE VERIFYONLY WITH CHECKSUM and perform
an isolated test restore to verify recoverability.

---

### 9. RESTORE VERIFICATION

The script reads restore history from:

msdb.dbo.restorehistory

It displays:

- Restore history ID.
- Destination database.
- Restore date.
- Restored by.
- Restore type.

The script also displays collected restore records from:

CECB_Monitoring.dbo.DatabaseRestoreHistory

The two result sets can be compared to identify
whether restore events have been collected.

---

### 10. EXECUTION REQUIREMENTS

Required components:

- SQL Server Management Studio.
- Access to the approved SQL Server instance.
- Permission to view server-level metadata.
- Permission to read the required monitoring database objects.
- Permission to read msdb backup and restore history.

Run the script using an approved DBA or monitoring account.

Some server-level results may be restricted if the account
does not have the required permissions.

---

### 11. EXECUTION PROCEDURE

Step 1:
Connect to the approved SQL Server instance using SSMS.

Step 2:
Open:

10_Verification\01_Verify_System.sql

Step 3:
Confirm the SQL Server connection and target environment.

Step 4:
Execute the complete script.

Step 5:
Review each result set.

Step 6:
Identify missing objects or inactive components.

Step 7:
Compare backup and restore history with the expected
deployment configuration.

Step 8:
Record any issues for DBA review.

---

### 12. VERIFICATION RESULTS

Expected results:

- Required databases should be ONLINE.
- Required monitoring tables should exist.
- Collector stored procedures should exist.
- Reporting views should exist.
- Approved SQL Server Audits should have the expected status.
- Extended Events should have the expected status.
- Monitoring records should be collected.
- Backup history should show successful backup operations.
- Restore history should be available when restore operations occur.

A component marked MISSING requires investigation.

A disabled Audit or inactive Extended Events session
must be reviewed against the approved configuration.

A zero record count does not necessarily indicate failure.
It may mean that no matching events have occurred yet.

---

### 13. TROUBLESHOOTING

Database not found:
Check database names and deployment status.

Table missing:
Review the Monitoring Database deployment scripts.

Stored procedure missing:
Review the Collector deployment scripts.

Report view missing:
Review the Reports deployment scripts.

Audit not enabled:
Review the approved SQL Server Audit configuration.

Extended Events not running:
Check the session configuration and SQL Server error logs.

No monitoring records:
Check collection tasks, SQL Audit files and collector logs.

No backup records:
Check backup task execution and SQL Server backup history.

Permission error:
Request the appropriate permissions from the DBA.

---

### 14. SECURITY AND OPERATIONAL NOTES

- Execute verification using an approved account.
- Do not grant additional permissions without DBA approval.
- Do not enable or disable Audits through this script.
- Do not modify existing production databases.
- Protect monitoring and backup information.
- Record verification results for deployment review.
- Perform isolated restore testing before production acceptance.

---

### 15. EXPECTED RESULT

The verification component should provide a clear overview
of the deployment status of the CECB Monitoring System.

It supports:

- Installation verification.
- Monitoring component verification.
- Audit configuration verification.
- Error monitoring verification.
- Backup history verification.
- Restore history verification.
- Operational troubleshooting.

Project:

SQL Server Database Activity Monitoring, Backup and Restore Management System

Organization:

Central Engineering Consultancy Bureau (CECB)

Document:

System Verification – Technical README

Deployment Status:

Proposed – Pending Production Approval