USE [CECB_Monitoring];
GO

SET NOCOUNT ON;
GO

PRINT '============================================';
PRINT ' CECB SQL AUDIT COLLECTION';
PRINT '============================================';
PRINT 'Starting user activity collection...';
GO

IF OBJECT_ID(
    N'dbo.usp_CollectUserActivity',
    N'P'
) IS NULL
BEGIN
    THROW 50010,
        'Stored Procedure dbo.usp_CollectUserActivity does not exist.',
        1;
END;
GO

EXEC dbo.usp_CollectUserActivity;
GO

PRINT 'User activity collection completed.';
PRINT '============================================';
GO