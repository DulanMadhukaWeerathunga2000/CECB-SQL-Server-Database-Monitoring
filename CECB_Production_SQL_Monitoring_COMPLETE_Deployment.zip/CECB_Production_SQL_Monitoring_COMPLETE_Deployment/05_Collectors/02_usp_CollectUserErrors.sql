USE [CECB_Monitoring];
GO

CREATE OR ALTER PROCEDURE dbo.usp_CollectUserErrors
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LockResult INT;

    EXEC @LockResult = sys.sp_getapplock
        @Resource = N'CECB_UserErrors_Collection',
        @LockMode = N'Exclusive',
        @LockOwner = N'Session',
        @LockTimeout = 10000;

    IF @LockResult < 0
    BEGIN
        THROW 50002,
            'Could not obtain user error collection lock.',
            1;
    END;

    BEGIN TRY

        ;WITH XEventData AS
        (
            SELECT
                file_name,
                file_offset,
                CAST(event_data AS XML) AS EventXML
            FROM sys.fn_xe_file_target_read_file
            (
                N'C:\CECB_Audit\CECB_Error_Monitor*.xel',
                NULL,
                NULL,
                NULL
            )
        ),
        ParsedData AS
        (
            SELECT
                DATEADD
                (
                    MINUTE,
                    330,
                    TRY_CONVERT
                    (
                        DATETIME2(3),
                        X.EventXML.value
                        (
                            '(/event/@timestamp)[1]',
                            'NVARCHAR(50)'
                        ),
                        127
                    )
                ) AS EventTime,

                X.EventXML.value
                (
                    '(/event/data[@name="error_number"]/value)[1]',
                    'INT'
                ) AS ErrorNumber,

                X.EventXML.value
                (
                    '(/event/data[@name="severity"]/value)[1]',
                    'INT'
                ) AS Severity,

                X.EventXML.value
                (
                    '(/event/data[@name="state"]/value)[1]',
                    'INT'
                ) AS ErrorState,

                X.EventXML.value
                (
                    '(/event/action[@name="username"]/value)[1]',
                    'NVARCHAR(256)'
                ) AS UserName,

                X.EventXML.value
                (
                    '(/event/action[@name="client_hostname"]/value)[1]',
                    'NVARCHAR(256)'
                ) AS PCName,

                X.EventXML.value
                (
                    '(/event/action[@name="database_name"]/value)[1]',
                    'NVARCHAR(256)'
                ) AS DatabaseName,

                X.EventXML.value
                (
                    '(/event/action[@name="client_app_name"]/value)[1]',
                    'NVARCHAR(512)'
                ) AS ApplicationName,

                X.EventXML.value
                (
                    '(/event/action[@name="sql_text"]/value)[1]',
                    'NVARCHAR(MAX)'
                ) AS SQLStatement,

                X.EventXML.value
                (
                    '(/event/data[@name="message"]/value)[1]',
                    'NVARCHAR(MAX)'
                ) AS ErrorMessage,

                X.file_name AS XELFileName,
                X.file_offset AS XELFileOffset

            FROM XEventData X
        )

        INSERT INTO dbo.UserErrorLog
        (
            EventTime,
            ErrorNumber,
            Severity,
            ErrorState,
            UserName,
            PCName,
            DatabaseName,
            ApplicationName,
            SQLStatement,
            ErrorMessage,
            XELFileName,
            XELFileOffset
        )
        SELECT
            P.EventTime,
            P.ErrorNumber,
            P.Severity,
            P.ErrorState,
            P.UserName,
            P.PCName,
            P.DatabaseName,
            P.ApplicationName,
            P.SQLStatement,
            P.ErrorMessage,
            P.XELFileName,
            P.XELFileOffset

        FROM ParsedData P

        WHERE P.EventTime IS NOT NULL
          AND NOT EXISTS
          (
              SELECT 1
              FROM dbo.UserErrorLog L
              WHERE L.XELFileName = P.XELFileName
                AND L.XELFileOffset = P.XELFileOffset
          );

        EXEC sys.sp_releaseapplock
            @Resource = N'CECB_UserErrors_Collection',
            @LockOwner = N'Session';

    END TRY
    BEGIN CATCH

        EXEC sys.sp_releaseapplock
            @Resource = N'CECB_UserErrors_Collection',
            @LockOwner = N'Session';

        THROW;

    END CATCH;
END;
GO