# CECB SQL SERVER DATABASE MONITORING SYSTEM
## 05 – COLLECTORS FOLDER README

### 1. PURPOSE

This folder contains the SQL Server Stored Procedures and execution scripts required to collect:

- SQL Server Audit Activities
- SQL Server Error Events
- Database Restore History

Collected information is stored in the `CECB_Monitoring` database for reporting and monitoring purposes.

**IMPORTANT:** These scripts are prepared for proposed production deployment. Do not execute them on the original CECB Production SQL Server until DBA/PM approval has been obtained.

---

### 2. FILE STRUCTURE

```text
05_Collectors
│
├── README_Collectors.txt
├── 01_usp_CollectUserActivity.sql
├── 02_usp_CollectUserErrors.sql
├── 03_usp_CollectRestoreHistory.sql
├── 04_Collect_Audit.sql
├── 05_Collect_Errors.sql
├── 06_Collect_RestoreHistory.sql
└── 07_Collect_All.bat
```

---

### 3. FILE DESCRIPTIONS

#### File 01 – 01_usp_CollectUserActivity.sql

**Purpose:**
Creates or updates the `dbo.usp_CollectUserActivity` stored procedure.

**Functions:**
- Reads SQL Server Audit files.
- Collects login and logout activities.
- Collects SELECT, INSERT, UPDATE and DELETE activities.
- Collects CREATE, ALTER, DROP and EXECUTE activities.
- Identifies SQL login, PC name and client IP when available.
- Maps usernames to their assigned user roles.
- Prevents duplicate audit records.

**Required source:**
`C:\CECB_Audit\*.sqlaudit`

**Target table:**
`dbo.UserActivityLog`

#### File 02 – 02_usp_CollectUserErrors.sql

**Purpose:**
Creates or updates the `dbo.usp_CollectUserErrors` stored procedure.

**Functions:**
- Reads SQL Server Extended Events files.
- Collects SQL Server error events.
- Records error number, severity and state.
- Captures username, PC name and database name when available.
- Records SQL statements and error messages.
- Prevents duplicate error records.

**Required source:**
`C:\CECB_Audit\CECB_Error_Monitor*.xel`

**Target table:**
`dbo.UserErrorLog`

#### File 03 – 03_usp_CollectRestoreHistory.sql

**Purpose:**
Creates or updates the `dbo.usp_CollectRestoreHistory` stored procedure.

**Functions:**
- Reads SQL Server restore history from `msdb`.
- Identifies restored database names.
- Collects restore dates and usernames.
- Retrieves backup file information when available.
- Prevents duplicate restore history records.

**Source:**
`msdb.dbo.restorehistory`

**Target table:**
`dbo.DatabaseRestoreHistory`

#### File 04 – 04_Collect_Audit.sql

**Purpose:**
Executes `dbo.usp_CollectUserActivity`.

**Function:**
Collects SQL Server Audit activity and stores new records in `UserActivityLog`.

#### File 05 – 05_Collect_Errors.sql

**Purpose:**
Executes `dbo.usp_CollectUserErrors`.

**Function:**
Collects Extended Events error records and stores them in `UserErrorLog`.

#### File 06 – 06_Collect_RestoreHistory.sql

**Purpose:**
Executes `dbo.usp_CollectRestoreHistory`.

**Function:**
Collects database restore history and stores new records in `DatabaseRestoreHistory`.

#### File 07 – 07_Collect_All.bat

**Purpose:**
Runs all three collection scripts automatically.

**Execution sequence:**

1. Collect SQL Audit Activities.
2. Collect SQL Error Events.
3. Collect Database Restore History.
4. Save execution results in a log file.
5. Return success or failure status.

**Log location:**
`Logs\Collection_YYYYMMDD_HHMMSS.log`

---

### 4. DEPENDENCIES

The following components must be configured before using these scripts:

1. SQL Server Database Engine.
2. `CECB_Monitoring` database.
3. `UserActivityLog` table.
4. `UserErrorLog` table.
5. `DatabaseRestoreHistory` table.
6. `UserRoleMap` table.
7. SQL Server Audit configuration.
8. Extended Events error monitoring session.
9. `C:\CECB_Audit\` directory.
10. SQL Server `sqlcmd` utility.

The SQL Server Database Engine service account must have the required permissions to read the audit and Extended Events files.

The Windows account running the batch file must have the required SQL Server and log-folder permissions.

---

### 5. CONFIGURATION BEFORE PRODUCTION DEPLOYMENT

Open `07_Collect_All.bat` using Notepad.

Review these settings:

```bat
SET "BASE_DIR=C:\CECB_Production_SQL_Monitoring_COMPLETE_Deployment"

SET "SQL_DIR=%BASE_DIR%\05_Collectors"

SET "LOG_DIR=%BASE_DIR%\Logs"

SET "SQL_SERVER=REPLACE_WITH_PRODUCTION_SQL_INSTANCE"

SET "DATABASE=CECB_Monitoring"
```

Replace the SQL Server placeholder with the DBA-approved production instance name.

Verify that all directory paths are correct.

Do not use the local test SQL Server instance for production deployment.

---

### 6. EXECUTION ORDER

Execute the files in the following order:

**First – Create Stored Procedures**

1. `01_usp_CollectUserActivity.sql`
2. `02_usp_CollectUserErrors.sql`
3. `03_usp_CollectRestoreHistory.sql`

**Second – Test Individual Collectors**

4. `04_Collect_Audit.sql`
5. `05_Collect_Errors.sql`
6. `06_Collect_RestoreHistory.sql`

**Third – Run Combined Collection**

7. `07_Collect_All.bat`

The combined batch file executes the three collection scripts in the correct order.

---

### 7. HOW TO EXECUTE

#### Method A – SQL Server Management Studio

1. Open SQL Server Management Studio.
2. Connect to the approved SQL Server instance.
3. Open the relevant `.sql` file.
4. Verify the database and script configuration.
5. Execute the script.
6. Review the Messages and Results tabs.
7. Confirm successful execution.

#### Method B – Windows Command Prompt

Open Command Prompt and navigate to the deployment folder.

Example:

```bat
cd /d C:\CECB_Production_SQL_Monitoring_COMPLETE_Deployment\05_Collectors
```

Execute:

```bat
07_Collect_All.bat
```

Review the generated log file in the `Logs` directory.

---

### 8. VERIFICATION

After collection, verify the records using:

```sql
USE CECB_Monitoring;
GO

SELECT COUNT(*) AS TotalUserActivities
FROM dbo.UserActivityLog;

SELECT COUNT(*) AS TotalUserErrors
FROM dbo.UserErrorLog;

SELECT COUNT(*) AS TotalRestoreRecords
FROM dbo.DatabaseRestoreHistory;
GO
```

Review recent activity:

```sql
SELECT TOP (50) *
FROM dbo.UserActivityLog
ORDER BY EventTime DESC;
```

Review recent errors:

```sql
SELECT TOP (50) *
FROM dbo.UserErrorLog
ORDER BY EventTime DESC;
```

Review restore history:

```sql
SELECT TOP (50) *
FROM dbo.DatabaseRestoreHistory
ORDER BY RestoreDate DESC;
```

---

### 9. TROUBLESHOOTING

**Problem: SQL Server Audit file not found**

Check:
- Audit file directory.
- SQL Server service account permissions.
- SQL Server Audit status.
- Audit file target configuration.

**Problem: Extended Events file not found**

Check:
- Extended Events session status.
- XEL file path.
- SQL Server service account permissions.

**Problem: Stored Procedure not found**

Execute the corresponding Stored Procedure creation script first.

**Problem: Access denied**

Check SQL Server permissions and Windows folder permissions with the DBA.

**Problem: Duplicate key error**

Check the corresponding source-file unique indexes and duplicate prevention logic.

**Problem: sqlcmd command not recognized**

Install or configure the SQL Server command-line utilities and verify that `sqlcmd` is available in the Windows PATH.

---

### 10. IMPORTANT SECURITY AND DEPLOYMENT NOTES

- Do not execute production scripts without approval.
- Do not disable existing SQL Server Audit configurations.
- Do not delete existing audit files.
- Do not change existing production database permissions without DBA approval.
- Protect monitoring logs because they may contain sensitive SQL statements and user information.
- Restrict access to monitoring tables and reports.
- Confirm that audit files are being retained according to CECB policy.
- Test collection and duplicate prevention before scheduling automatic execution.
- Keep the existing production monitoring and backup arrangements until the new system is validated.

---

### 11. EXPECTED RESULT

After successful configuration, the collector system should provide:

- Centralized user activity records.
- SQL Server error monitoring records.
- Database restore history.
- User and role-based activity information.
- Automated collection logs.
- Data for daily, monthly and detailed monitoring reports.

**Project:** SQL Server Database Activity Monitoring, Backup and Restore Management System

**Organization:** Central Engineering Consultancy Bureau (CECB)

**Document:** Collector Scripts – Technical README

**Deployment Status:** Proposed – Pending Production Approval