USE [CECB_Monitoring];
GO

SET NOCOUNT ON;
GO

PRINT '============================================';
PRINT ' CECB DATABASE RESTORE HISTORY COLLECTION';
PRINT '============================================';

PRINT 'Starting restore history collection...';
GO

IF OBJECT_ID(
    N'dbo.usp_CollectRestoreHistory',
    N'P'
) IS NULL
BEGIN
    THROW 50012,
        'Stored Procedure dbo.usp_CollectRestoreHistory does not exist.',
        1;
END;
GO

EXEC dbo.usp_CollectRestoreHistory;
GO

PRINT 'Restore history collection completed.';
PRINT '============================================';
GO