USE [CECB_Monitoring];
GO

CREATE OR ALTER PROCEDURE dbo.usp_CollectUserActivity
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LockResult INT;

    EXEC @LockResult = sys.sp_getapplock
        @Resource = N'CECB_UserActivity_Collection',
        @LockMode = N'Exclusive',
        @LockOwner = N'Session',
        @LockTimeout = 10000;

    IF @LockResult < 0
    BEGIN
        THROW 50001, 'Could not obtain activity collection lock.', 1;
    END;

    BEGIN TRY

        ;WITH AuditData AS
        (
            SELECT
                event_time,
                session_server_principal_name,
                server_principal_name,
                database_principal_name,
                host_name,
                client_ip,
                database_name,
                schema_name,
                object_name,
                action_id,
                statement,
                succeeded,
                application_name,
                file_name,
                audit_file_offset,
                sequence_group_id,
                sequence_number
            FROM sys.fn_get_audit_file
            (
                N'C:\CECB_Audit\*.sqlaudit',
                DEFAULT,
                DEFAULT
            )
            WHERE action_id IN
            (
                'SL', 'IN', 'UP', 'DL',
                'CR', 'AL', 'DR', 'EX',
                'LGIS', 'LGIF', 'LGO'
            )
        ),
        PreparedData AS
        (
            SELECT
                DATEADD(MINUTE, 330, event_time) AS EventTime,

                COALESCE(
                    NULLIF(session_server_principal_name, ''),
                    NULLIF(server_principal_name, ''),
                    NULLIF(database_principal_name, ''),
                    'Unknown'
                ) AS UserName,

                ISNULL(NULLIF(host_name, ''), 'Unknown') AS PCName,

                client_ip AS IPAddress,

                database_name AS DatabaseName,
                schema_name AS SchemaName,
                object_name AS TableName,

                CASE action_id
                    WHEN 'LGIS' THEN 'LOGIN'
                    WHEN 'LGIF' THEN 'FAILED LOGIN'
                    WHEN 'LGO'  THEN 'LOGOUT'
                    WHEN 'SL'   THEN 'SELECT'
                    WHEN 'IN'   THEN 'INSERT'
                    WHEN 'UP'   THEN 'UPDATE'
                    WHEN 'DL'   THEN 'DELETE'
                    WHEN 'CR'   THEN 'CREATE'
                    WHEN 'AL'   THEN 'ALTER'
                    WHEN 'DR'   THEN 'DROP'
                    WHEN 'EX'   THEN 'EXECUTE'
                    ELSE action_id
                END AS Activity,

                statement AS SQLStatement,

                CASE
                    WHEN succeeded = 1 THEN 'Success'
                    ELSE 'Failed'
                END AS Status,

                application_name AS ApplicationName,

                file_name AS AuditFileName,
                audit_file_offset AS AuditFileOffset,
                sequence_number AS AuditSequenceNumber,
                sequence_group_id AS SequenceGroupID

            FROM AuditData
        )
        INSERT INTO dbo.UserActivityLog
        (
            EventTime,
            UserName,
            UserRole,
            PCName,
            IPAddress,
            DatabaseName,
            SchemaName,
            TableName,
            Activity,
            SQLStatement,
            Status,
            AuditFileName,
            AuditFileOffset,
            AuditSequenceNumber,
            SequenceGroupID,
            ApplicationName
        )
        SELECT
            P.EventTime,
            P.UserName,

            ISNULL(R.UserRole, 'Unmapped'),

            P.PCName,
            P.IPAddress,
            P.DatabaseName,
            P.SchemaName,
            P.TableName,
            P.Activity,
            P.SQLStatement,
            P.Status,
            P.AuditFileName,
            P.AuditFileOffset,
            P.AuditSequenceNumber,
            P.SequenceGroupID,
            P.ApplicationName

        FROM PreparedData P

        OUTER APPLY
        (
            SELECT TOP (1) URM.UserRole
            FROM dbo.UserRoleMap URM
            WHERE URM.IsActive = 1
              AND
              (
                  URM.UserName = P.UserName
                  OR
                  (
                      CHARINDEX('\', P.UserName) > 0
                      AND URM.UserName =
                          RIGHT(P.UserName,
                                CHARINDEX('\', REVERSE(P.UserName)) - 1)
                  )
              )
            ORDER BY
                CASE
                    WHEN URM.UserName = P.UserName THEN 0
                    ELSE 1
                END
        ) R

        WHERE NOT EXISTS
        (
            SELECT 1
            FROM dbo.UserActivityLog L
            WHERE L.AuditFileName = P.AuditFileName
              AND L.AuditFileOffset = P.AuditFileOffset
        );

        EXEC sys.sp_releaseapplock
            @Resource = N'CECB_UserActivity_Collection',
            @LockOwner = N'Session';

    END TRY
    BEGIN CATCH

        EXEC sys.sp_releaseapplock
            @Resource = N'CECB_UserActivity_Collection',
            @LockOwner = N'Session';

        THROW;

    END CATCH;
END;
GO