USE [CECB_Monitoring];
GO

SET NOCOUNT ON;
GO

PRINT '============================================';
PRINT ' CECB SQL ERROR COLLECTION';
PRINT '============================================';

PRINT 'Starting SQL error collection...';
GO

IF OBJECT_ID(
    N'dbo.usp_CollectUserErrors',
    N'P'
) IS NULL
BEGIN
    THROW 50011,
        'Stored Procedure dbo.usp_CollectUserErrors does not exist.',
        1;
END;
GO

EXEC dbo.usp_CollectUserErrors;
GO

PRINT 'SQL error collection completed.';
PRINT '============================================';
GO