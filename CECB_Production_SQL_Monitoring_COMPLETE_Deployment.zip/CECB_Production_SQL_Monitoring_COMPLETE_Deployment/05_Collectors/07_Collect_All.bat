@echo off
SETLOCAL ENABLEEXTENSIONS

REM =====================================================
REM CECB SQL SERVER MONITORING - AUTOMATIC COLLECTION
REM =====================================================

SET "BASE_DIR=C:\CECB_Production_SQL_Monitoring_COMPLETE_Deployment"
SET "SQL_DIR=%BASE_DIR%\05_Collectors"
SET "LOG_DIR=%BASE_DIR%\Logs"

REM REPLACE WITH APPROVED PRODUCTION SQL INSTANCE
SET "SQL_SERVER=REPLACE_WITH_PRODUCTION_SQL_INSTANCE"

SET "DATABASE=CECB_Monitoring"

REM Create log directory if it does not exist
IF NOT EXIST "%LOG_DIR%" (
    MKDIR "%LOG_DIR%"
)

REM Create timestamp for log file
FOR /F %%A IN ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') DO SET "RUN_TIME=%%A"

SET "LOG_FILE=%LOG_DIR%\Collection_%RUN_TIME%.log"

ECHO ===================================================== > "%LOG_FILE%"
ECHO CECB DATABASE MONITORING COLLECTION >> "%LOG_FILE%"
ECHO Started: %DATE% %TIME% >> "%LOG_FILE%"
ECHO SQL Server: %SQL_SERVER% >> "%LOG_FILE%"
ECHO ===================================================== >> "%LOG_FILE%"

REM -----------------------------------------------------
REM 1. COLLECT AUDIT ACTIVITY
REM -----------------------------------------------------

ECHO.
ECHO [1/3] Collecting SQL Audit Activity...

sqlcmd -S "%SQL_SERVER%" -d "%DATABASE%" -E -b -r1 -i "%SQL_DIR%\04_Collect_Audit.sql" >> "%LOG_FILE%" 2>&1

IF ERRORLEVEL 1 GOTO ERROR_EXIT

ECHO Audit collection completed.

REM -----------------------------------------------------
REM 2. COLLECT SQL ERRORS
REM -----------------------------------------------------

ECHO.
ECHO [2/3] Collecting SQL Error Events...

sqlcmd -S "%SQL_SERVER%" -d "%DATABASE%" -E -b -r1 -i "%SQL_DIR%\05_Collect_Errors.sql" >> "%LOG_FILE%" 2>&1

IF ERRORLEVEL 1 GOTO ERROR_EXIT

ECHO Error collection completed.

REM -----------------------------------------------------
REM 3. COLLECT RESTORE HISTORY
REM -----------------------------------------------------

ECHO.
ECHO [3/3] Collecting Database Restore History...

sqlcmd -S "%SQL_SERVER%" -d "%DATABASE%" -E -b -r1 -i "%SQL_DIR%\06_Collect_RestoreHistory.sql" >> "%LOG_FILE%" 2>&1

IF ERRORLEVEL 1 GOTO ERROR_EXIT

ECHO Restore history collection completed.

REM -----------------------------------------------------
REM SUCCESS
REM -----------------------------------------------------

ECHO. >> "%LOG_FILE%"
ECHO STATUS: SUCCESS >> "%LOG_FILE%"
ECHO Completed: %DATE% %TIME% >> "%LOG_FILE%"

ECHO.
ECHO =====================================================
ECHO ALL COLLECTION TASKS COMPLETED SUCCESSFULLY
ECHO =====================================================

EXIT /B 0

REM -----------------------------------------------------
REM ERROR HANDLING
REM -----------------------------------------------------

:ERROR_EXIT

ECHO. >> "%LOG_FILE%"
ECHO STATUS: FAILED >> "%LOG_FILE%"
ECHO Failed: %DATE% %TIME% >> "%LOG_FILE%"

ECHO.
ECHO =====================================================
ECHO COLLECTION FAILED!
ECHO CHECK LOG FILE:
ECHO %LOG_FILE%
ECHO =====================================================

EXIT /B 1