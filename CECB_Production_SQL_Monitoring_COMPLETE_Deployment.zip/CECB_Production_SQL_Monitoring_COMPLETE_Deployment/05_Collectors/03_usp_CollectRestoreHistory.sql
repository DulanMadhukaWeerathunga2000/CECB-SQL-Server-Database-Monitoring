USE [CECB_Monitoring];
GO

CREATE OR ALTER PROCEDURE dbo.usp_CollectRestoreHistory
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LockResult INT;

    EXEC @LockResult = sys.sp_getapplock
        @Resource = N'CECB_RestoreHistory_Collection',
        @LockMode = N'Exclusive',
        @LockOwner = N'Session',
        @LockTimeout = 10000;

    IF @LockResult < 0
    BEGIN
        THROW 50003,
            'Could not obtain restore history collection lock.',
            1;
    END;

    BEGIN TRY

        ;WITH RestoreData AS
        (
            SELECT
                RH.restore_history_id AS RestoreHistoryID,
                RH.restore_date AS RestoreDate,
                RH.destination_database_name AS DatabaseName,
                RH.user_name AS RestoredBy,

                (
                    SELECT TOP (1)
                        BSF.physical_device_name
                    FROM msdb.dbo.backupset BS
                    INNER JOIN msdb.dbo.backupmediafamily BSF
                        ON BS.media_set_id = BSF.media_set_id
                    WHERE BS.backup_set_id = RH.backup_set_id
                ) AS BackupFile

            FROM msdb.dbo.restorehistory RH
            WHERE RH.destination_database_name IS NOT NULL
        )

        INSERT INTO dbo.DatabaseRestoreHistory
        (
            RestoreHistoryID,
            RestoreDate,
            DatabaseName,
            BackupFile,
            RestoredBy,
            PCName,
            RestoreStatus,
            Remarks
        )
        SELECT
            R.RestoreHistoryID,
            R.RestoreDate,
            R.DatabaseName,
            R.BackupFile,
            R.RestoredBy,
            NULL,
            'SUCCESS',
            'Collected automatically from msdb restore history.'

        FROM RestoreData R

        WHERE NOT EXISTS
        (
            SELECT 1
            FROM dbo.DatabaseRestoreHistory H
            WHERE H.RestoreHistoryID = R.RestoreHistoryID
        );

        EXEC sys.sp_releaseapplock
            @Resource = N'CECB_RestoreHistory_Collection',
            @LockOwner = N'Session';

    END TRY
    BEGIN CATCH

        EXEC sys.sp_releaseapplock
            @Resource = N'CECB_RestoreHistory_Collection',
            @LockOwner = N'Session';

        THROW;

    END CATCH;
END;
GO